

//_____________________________________________________________
//_____________________________________________________________

// https://medium.com/@dileep.ducs/swift-protocols-and-delegates-156d892d2abb
// https://mimo.org/glossary/swift/protocol
// https://www.kodeco.com/44907799-protocols-in-ios-object-oriented-programming

//_____________________________________________________________
//_____________________________________________________________

//====================================================
// 🔹 Topic: Protocols & Delegates in Swift
//====================================================
//
// Explanation:
// This example demonstrates the Delegate pattern using
// Swift protocols. One object notifies another object
// when an event occurs, without tightly coupling them.
//
//====================================================

// Step 1: Define a delegate protocol
protocol SomeDelegate: AnyObject {
    func didSomething()
}

// Step 2: Create a class that uses the delegate
class SomeClass {
    weak var delegate: SomeDelegate?

    func performTask() {
        print("Task is being performed")
        delegate?.didSomething()
    }
}

// Step 3: Create another class that adopts the delegate protocol
class AnotherClass: SomeDelegate {
    let someObject = SomeClass()

    init() {
        someObject.delegate = self
    }

    func didSomething() {
        print("Delegate method called")
    }
}

// Step 4: Run the example
let obj = AnotherClass()
obj.someObject.performTask()

/*
 OUTPUT:
 Task is being performed
 Delegate method called
*/








//====================================================
// EXAMPLE 1: Protocol + Inheritance + Protocol Adoption
//====================================================

protocol Vehicle {
    var make: String { get }
    var model: String { get }
    func drive()
}

class Car: Vehicle {
    let make: String
    let model: String

    init(make: String, model: String) {
        self.make = make
        self.model = model
    }

    func drive() {
        print("Driving the \(make) \(model).")
    }
}

protocol Chargeable {
    func charge()
}

class ElectricCar: Car, Chargeable {
    func charge() {
        print("Charging the \(make) \(model).")
    }
}

// Usage
let tesla = ElectricCar(make: "Tesla", model: "Model 3")
tesla.drive()
tesla.charge()






//====================================================
// EXAMPLE 2: SHOPPING CART USING PROTOCOLS
//====================================================

protocol Item {
    var name: String { get set }
    var price: Double { get set }
}

// Physical Item
struct PhysicalItem: Item {
    var name: String
    var price: Double
    let weightInGrams: Int
}

// Digital Item
struct DigitalItem: Item {
    var name: String
    var price: Double
    let downloadSize: String
}

// ShoppingCart Protocol
protocol ShoppingCart {
    var items: [Item] { get set }
    mutating func addItem(_ item: Item)
    func calculateTotalPrice() -> Double
}

// Shopping Cart Implementation
struct BasicCart: ShoppingCart {
    var items: [Item] = []

    mutating func addItem(_ item: Item) {
        items.append(item)
    }

    func calculateTotalPrice() -> Double {
        var total = 0.0
        for item in items {
            total += item.price
        }
        return total
    }
}

// Usage
var cart = BasicCart()

let milk = PhysicalItem(name: "Milk", price: 2.99, weightInGrams: 946)
let ebook = DigitalItem(name: "Swift Programming Guide", price: 9.99, downloadSize: "10MB")

cart.addItem(milk)
cart.addItem(ebook)

let totalPrice = cart.calculateTotalPrice()
print("Total price: $\(totalPrice)")



//====================================================
// PROTOCOL BASICS
//====================================================

protocol Greetable {
    var name: String { get }
    func greet()
}

struct Person: Greetable {
    var name: String
    func greet() {
        print("Hello, my name is \(name).")
    }
}

let john = Person(name: "John")
john.greet()


//====================================================
// PROTOCOL PROPERTIES
//====================================================

protocol VehicleProperties {
    var speed: Int { get set }
    var capacity: Int { get }
}


//====================================================
// PROTOCOL METHODS
//====================================================

protocol Drivable {
    func start()
    func stop()
}

class Car: Drivable {
    func start() {
        print("Car is starting...")
    }

    func stop() {
        print("Car is stopping...")
    }
}

let car = Car()
car.start()
car.stop()


//====================================================
// STANDARDIZING BEHAVIOR
//====================================================

protocol Flyable {
    func fly()
}

struct Bird: Flyable {
    func fly() {
        print("The bird is flying.")
    }
}

struct Plane: Flyable {
    func fly() {
        print("The plane is flying.")
    }
}

let flyer1: Flyable = Bird()
let flyer2: Flyable = Plane()
flyer1.fly()
flyer2.fly()


//====================================================
// FLEXIBLE CODE
//====================================================

protocol Storable {
    func save()
}

class Document: Storable {
    func save() {
        print("Saving document...")
    }
}

class Image: Storable {
    func save() {
        print("Saving image...")
    }
}

let items: [Storable] = [Document(), Image()]
items.forEach { $0.save() }


//====================================================
// DELEGATION
//====================================================

protocol DownloadDelegate: AnyObject {
    func didFinishDownloading()
}

class Downloader {
    weak var delegate: DownloadDelegate?

    func download() {
        print("Downloading...")
        delegate?.didFinishDownloading()
    }
}

class ViewController: DownloadDelegate {
    func didFinishDownloading() {
        print("Download complete!")
    }
}

let vc = ViewController()
let downloader = Downloader()
downloader.delegate = vc
downloader.download()


//====================================================
// PROTOCOL WITH ARRAY
//====================================================

protocol Animal {
    func makeSound()
}

struct Dog: Animal {
    func makeSound() {
        print("Woof!")
    }
}

struct Cat: Animal {
    func makeSound() {
        print("Meow!")
    }
}

let animals: [Animal] = [Dog(), Cat()]
animals.forEach { $0.makeSound() }


//====================================================
// PROTOCOL EXTENSION
//====================================================

protocol Identifiable {
    var id: String { get }
}

extension Identifiable {
    func identify() {
        print("My ID is \(id).")
    }
}

struct User: Identifiable {
    var id: String
}

let user = User(id: "123")
user.identify()


//====================================================
// GENERICS + PROTOCOLS
//====================================================

protocol Storage {
    associatedtype Item
    func store(_ item: Item)
}

class Box<T>: Storage {
    func store(_ item: T) {
        print("Storing \(item)")
    }
}

let intBox = Box<Int>()
intBox.store(42)


//====================================================
// PROTOCOL INHERITANCE
//====================================================

protocol Movable {
    func move()
}

protocol Stoppable {
    func stop()
}

protocol Vehicle: Movable, Stoppable {}

class Bicycle: Vehicle {
    func move() {
        print("Bicycle is moving.")
    }

    func stop() {
        print("Bicycle is stopping.")
    }
}

let bike = Bicycle()
bike.move()
bike.stop()


//====================================================
// CLASS-ONLY PROTOCOL
//====================================================

protocol ViewControllerDelegate: AnyObject {
    func didUpdate()
}


//====================================================
// OPTIONAL PROTOCOL METHODS
//====================================================

@objc protocol OptionalProtocol {
    @objc optional func optionalMethod()
}


//====================================================
// REAL-WORLD NETWORKING EXAMPLE
//====================================================

protocol NetworkService {
    func fetchData(from url: String)
}

class APIClient: NetworkService {
    func fetchData(from url: String) {
        print("Fetching data from \(url)")
    }
}

let apiClient: NetworkService = APIClient()
apiClient.fetchData(from: "https://example.com")

//====================================================
//====================================================

