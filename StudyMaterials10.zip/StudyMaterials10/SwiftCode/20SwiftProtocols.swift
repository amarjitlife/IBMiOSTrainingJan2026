//_____________________________________________________________
//_____________________________________________________________

class Human1 {
	var name : String = "Uknonwn"
	init( name: String ) { self.name = name }

	func fly() 			{ print("Fly Like Human!") 			}
	func saveWorld() 	{ print("Save World Like Human!") 	}
}

//_____________________________________________________________

// Enforces Contract
// 		What To Do
protocol Superpower {
	func fly()
	func saveWorld()
}

// Concrete Classes/Types
//		How, When, Where, Which, Way, Which Order To Do
class Spiderman : Superpower {
	func fly() 			{ print("Fly Like Spiderman!") 			}
	func saveWorld() 	{ print("Save World Like Spiderman!") 	}
}

class Superman : Superpower {
	func fly() 			{ print("Fly Like Superman!") 			}
	func saveWorld() 	{ print("Save World Like Superman!") 	}
}

class Batman : Superpower {
	func fly() 			{ print("Fly Like Batman!") 			}
	func saveWorld() 	{ print("Save World Like Batman!") 	}
}

class Wonderwoman : Superpower {
	func fly() 			{ print("Fly Like Wonderwoman!") 			}
	func saveWorld() 	{ print("Save World Like Wonderwoman!") 	}
}

//_____________________________________________________________

// Using Mechanims Inheritance
// 		Getting Functionality OR Code Reuse
// class Human : Spiderman {
// class Human : Superman {
class Human : Batman {
	var name : String = "Uknonwn"
	init( name: String ) { self.name = name }

	override func fly() 			{ super.fly() 		} // { print("Fly Like Human!") 			}
	override func saveWorld() 	{ super.saveWorld() } //  { print("Save World Like Human!") 	}
}

func playWithHuman() {
	print("Spiderman Capabilities...")
	let spider = Spiderman()
	spider.fly()
	spider.saveWorld()

	print("\nHuman Capabilities...")
	let gabbar = Human( name: "Gabbar Singh" )
	gabbar.fly()
	gabbar.saveWorld()
}

print("\nFunction: playWithHuman")
playWithHuman()

//_____________________________________________________________
//_____________________________________________________________

// Using Mechanims Composition
// 		Getting Functionality OR Code Reuse
class HumanBetter {
	// var power: Spiderman = Spiderman()
	// var power: Superman = Superman()
	var power: Batman = Batman()
	
	var name : String = "Uknonwn"
	init( name: String ) { self.name = name }

	func fly() 			{ power.fly() 		} 
	func saveWorld() 	{ power.saveWorld() } 
}

func playWithHumanBetter() {
	print("Spiderman Capabilities...")
	let spider = Spiderman()
	spider.fly()
	spider.saveWorld()

	print("\nHuman Capabilities...")
	let gabbar = HumanBetter( name: "Gabbar Singh" )
	gabbar.fly()
	gabbar.saveWorld()
}

print("\nFunction: playWithHumanBetter")
playWithHumanBetter()


//_____________________________________________________________
//_____________________________________________________________


class HumanBest {
	var power: Superpower? 

	var name : String = "Uknonwn"
	init( name: String ) { self.name = name }

	func fly() 			{ power?.fly() 		 } 
	func saveWorld() 	{ power?.saveWorld() } 
}

func playWithHumanBest() {
	print("Spiderman Capabilities...")
	let spider = Spiderman()
	spider.fly()
	spider.saveWorld()

	print("\nHuman Capabilities...")
	let gabbar = HumanBest( name: "Gabbar Singh" )
	
	gabbar.power = Spiderman()
	gabbar.fly()
	gabbar.saveWorld()

	gabbar.power = Superman()
	gabbar.fly()
	gabbar.saveWorld()

	gabbar.power = Batman()
	gabbar.fly()
	gabbar.saveWorld()

	gabbar.power = Wonderwoman()
	gabbar.fly()
	gabbar.saveWorld()
}

print("\nFunction: playWithHumanBest")
playWithHumanBest()


//_____________________________________________________________
//_____________________________________________________________

protocol FirstProtocol {
    // protocol definition goes here
}

protocol AnotherProtocol {

}

struct SomeStructure: FirstProtocol, AnotherProtocol {
    // structure definition goes here
}

//  If a class has a superclass, list the superclass name before any protocols it adopts, followed by a comma:

class SomeSuperclass {

}

class SomeClass: SomeSuperclass, FirstProtocol, AnotherProtocol {
    // class definition goes here
}


//_____________________________________________________________
//_____________________________________________________________

// Property Requirements

// Property requirements are 
        // always declared as variable properties, 
        // prefixed with the var keyword.

protocol SomeProtocol {
    var mustBeSettable: Int { get set }
    var doesNotNeedToBeSettable: Int { get }
}

//  Always prefix type property requirements with the static keyword 
        // when you define them in a protocol. 
        // This is true even though type property requirements 
                // can be prefixed with the static or class keyword 
                // when implemented by a class:

protocol AnotherProtocol1 {
    static var someTypeProperty: Int { get set }
}


//_____________________________________________________________
//_____________________________________________________________

// Here's an example of a protocol with 
//		a single instance property requirement:

protocol FullyNamed {
    var fullName: String { // Readonly Property
    	get 
    }
}

struct Person: FullyNamed {
    var fullName: String
}

class Starship: FullyNamed {
    var prefix: String?
    var name: String
    
    init(name: String, prefix: String? = nil) {
        self.name = name
        self.prefix = prefix
    }

    var fullName: String {
    	return ((prefix != nil ? prefix! + " " : "") + name)
    }
}

func playWithPropertyRequirement() {
	let john = Person(fullName: "John AppleSeed")
	let ncc1701 = Starship(name: "Enterprise", prefix: "USS")
	print( john.fullName )
	print( ncc1701.fullName )
}

print("\nFunction: playWithPropertyRequirement")
playWithPropertyRequirement()

//_____________________________________________________________
//_____________________________________________________________

// Method Requirements
//		Instance Level Method
//		Type Level Method

protocol SomeProtocol1 {
    // Type Level Method
    static func someTypeMethod()
}

protocol RandomNumberGenerator {
    // Instance Level Method
    func random() -> Double
}


// Class Following A Protocol RandomNumberGenerator
class LinearCongruentialGenerator: RandomNumberGenerator {
    var lastRandom = 42.0
    let m = 139968.0
    let a = 3877.0
    let c = 29573.0

    func random() -> Double {
        lastRandom = ((lastRandom * a + c).truncatingRemainder(dividingBy:m))
        return lastRandom / m
    }
}

func playWithMethodRequirements() {
	let generator = LinearCongruentialGenerator()
	print("Here's a random number: \(generator.random())")
	print("And another one: \(generator.random())")
}

print("\nFunction: playWithMethodRequirements")
playWithMethodRequirements()


//_____________________________________________________________
//_____________________________________________________________


// Mutating Method Requirements
protocol Togglable {
    mutating func toggle()
}

enum OnOffSwitch: Togglable {
    case off, on
    mutating func toggle() {
        switch self {
        case .off:
            self = .on
        case .on:
            self = .off
        }
    }
}


func playWithMutatingMethodRequirements() {
	var lightSwitch = OnOffSwitch.off
	print( lightSwitch )

	lightSwitch.toggle()
	print( lightSwitch )
}

print("\nFunction: playWithMutatingMethodRequirements")
playWithMutatingMethodRequirements()

//_____________________________________________________________
//_____________________________________________________________

// Initializer Requirements
// Protocols can require specific initializers 
        // to be implemented by conforming types.

protocol SomeProtocolWithInit {
    init(someParameter: Int)
}


// Class Implementations of Protocol Initializer Requirements
// You can implement a protocol initializer requirement 
        // on a conforming class as either a designated initializer 
        // Or a convenience initializer. 
        // In both cases, you must mark the initializer implementation 
                // with the required modifier

class SomeClassWithInit : SomeProtocolWithInit {
    required init(someParameter: Int) {
        // initializer implementation goes here
    }
}


// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________


// If a subclass overrides a designated initializer from a superclass, 
// and also implements a matching initializer requirement from a protocol, 
// mark the initializer implementation with 
        // both the required and override modifiers


protocol SomeProtocolWithInit1 {
    init()
}

class SomeSuperClass1 {
    init() {
        // initializer implementation goes here
    }
}

class SomeSubClass1: SomeSuperClass1, SomeProtocolWithInit1 {
    // "required" from SomeProtocol conformance; "override" from SomeSuperClass
    required override init() {
        // initializer implementation goes here
    }
}


// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// protocol RandomNumberGenerator {
//     func random() -> Double
// }

// // Class Following A Protocol RandomNumberGenerator
// class LinearCongruentialGenerator: RandomNumberGenerator {
//     var lastRandom = 42.0
//     let m = 139968.0
//     let a = 3877.0
//     let c = 29573.0

//     func random() -> Double {
//         lastRandom = ((lastRandom * a + c).truncatingRemainder(dividingBy:m))
//         return lastRandom / m
//     }
// }

class Dice {
    let sides: Int
    let generator: RandomNumberGenerator

    init(sides: Int, generator: RandomNumberGenerator) {
        self.sides = sides
        self.generator = generator
    }

    func roll() -> Int {
        return Int(generator.random() * Double(sides)) + 1
    }
}

func playWithDice() {
	let d6 = Dice(sides: 6, generator: LinearCongruentialGenerator())
	print( d6.sides )

	for _ in 1...5 {
	    print("Random dice roll is \(d6.roll())")
	}
}

print("\nFunction: playWithDice")
playWithDice()

//_____________________________________________________________
//_____________________________________________________________

// Delegation

protocol DiceGame {
    var dice: Dice { get }
    func play()
}

protocol DiceGameDelegate {
    func gameDidStart(game: DiceGame)
    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int)
    func gameDidEnd(game: DiceGame)
}

class SnakesAndLadders: DiceGame {
    let finalSquare = 25
    let dice = Dice(sides: 6, generator:LinearCongruentialGenerator())
    var square = 0
    var board: [Int]

    var delegate: DiceGameDelegate?
    
    init() {
        board = [Int](repeating: 0, count: finalSquare + 1)

        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
    }
    
    func play() {
        square = 0
        delegate?.gameDidStart(game: self)

        gameLoop: while square != finalSquare {
            let diceRoll = dice.roll()
            delegate?.game( game: self, didStartNewTurnWithDiceRoll: diceRoll)
            switch square + diceRoll {
            case finalSquare:
                break gameLoop
            case let newSquare where newSquare > finalSquare:
                continue gameLoop
            default:
                square += diceRoll
                square += board[square]
            }
        }
        delegate?.gameDidEnd( game: self)
    }
}

class DiceGameTracker: DiceGameDelegate {
    var numberOfTurns = 0
    
    func gameDidStart(game: DiceGame) {
        numberOfTurns = 0
        if game is SnakesAndLadders {
            print("Started a new game of Snakes and Ladders")
        }
        print("The game is using a \(game.dice.sides)-sided dice")
    }

    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int) {
        // ++numberOfTurns
        numberOfTurns = numberOfTurns + 1 
        print("Rolled a \(diceRoll)")
    }

    func gameDidEnd(game: DiceGame) {
        print("The game lasted for \(numberOfTurns) turns")
    }
}

func playWithDiceGame() {
	let tracker = DiceGameTracker()
	let game = SnakesAndLadders()
	game.delegate = tracker
	game.play()
}

print("\nFunction: playWithDiceGame")
playWithDiceGame()

//_____________________________________________________________
//_____________________________________________________________

// https://medium.com/@dileep.ducs/swift-protocols-and-delegates-156d892d2abb
// https://mimo.org/glossary/swift/protocol
// https://www.kodeco.com/44907799-protocols-in-ios-object-oriented-programming

//_____________________________________________________________
//_____________________________________________________________



