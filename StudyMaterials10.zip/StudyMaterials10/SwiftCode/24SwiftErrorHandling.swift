
//_____________________________________________________________
//_____________________________________________________________

// A guard statement is capable to transfer the flow of control of a program 
// if a certain condition(s) aren't met within the program. 
// Or we can say, if a condition expression evaluates true, 
// then the body of the guard statement is not executed. 
// In other words, the control flow of the program doesn't go inside 
// the body of the guard statement. Otherwise, if the condition evaluates false 
// then the body of the guard statement is executed.

//_____________________________________________________________
//_____________________________________________________________


// Swift program to demonstrate the working of
// guard statement inside a loop and using 
// continue control statement

func playWithGuardStatement() {
	// Initializing variable
	var num = 1

	print("Natural numbers from 1 to 10 which are divisible by 5 are: \n")

	// Iterating from 1 to 10 
	while (num <= 10) {
	    // Guard condition to check the divisibility by 5 
	    // If num is not divisible by 5 then execute the 
	    // body of the guard statement
	    guard num % 5 == 0 else {
	        num = num + 1
	        continue
	    }
	    
	    // Print the value represented by num
	    print(num)
	    
	    // Increment num by one
	    num = num + 1
	}
}

print("\nFunction: playWithGuardStatement")
playWithGuardStatement()

//_____________________________________________________________
//_____________________________________________________________

// Swift program to demonstrate the working of
// guard statement inside a loop and using 
// break control statement

func playWithGuardStatementAgain() {
	// Initializing variable
	var num = 1

	print("Natural numbers from 1 to 5 which are not divisible by 5 are: \n")

	// Iterating from 1 to 5
	while (num <= 5) {

	    // Guard condition to check the divisibility by 5 
	    // If num is divisible by 5 then execute the body 
	    // of the guard statement
	    guard num % 5 != 0 else {
	        num = num + 1
	        break
	    }
	    
	    // If num is not divisible by 5 then 
	    // print the value represented by num
	    print(num)
	    num = num + 1
	}
}

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________


// Swift program to demonstrate the working of
// guard statements in a function

// Create a function
func checkDivisibilityByfive(num: Int)  {

    // Use of guard statement
    guard num % 5 == 0 else {
        print("Not divisible by 5")
        return
    }

    print("Divisible by 5")
}

func playWithCheckDivisibilityByFive() {
	// Calling function
	checkDivisibilityByfive(num: 5)

	// Calling function
	checkDivisibilityByfive(num: 12)
}

print("\nFunction: playWithCheckDivisibilityByFive")
playWithCheckDivisibilityByFive()

//_____________________________________________________________
//_____________________________________________________________


// Swift program to demonstrate the working of
// guard statement with throw control statement

// Enum type for making error message
enum stringError: Error  {
    case non_numeric_string

}

// Function to convert string to an integer
func convertToInt(myString: String) throws  {

    // Using integer initializer
    // If myString is numeric then convert it 
    // using initializer Otherwise default type
    // will be assigned that is, -1
    let integerValue = Int(myString) ?? -1

    // If integerValue is -1 then guard 
    // statement will executed 
    guard integerValue != -1 else {
        throw stringError.non_numeric_string
    }
    
    // Otherwise this would be printed on console
    print("integerValue:", integerValue)    
}


func playWithErrorHandlingDoCatch() {
	// do-catch blocks
	do {
	    try convertToInt(myString: "12345")
	} catch {
	    print("[X] wrong string format: \(error)")
	}

	do {
	    try convertToInt(myString: "GeeksforGeeks")
	} catch {
	    print("[X] wrong string format: \(error)")
	}
}

print("\nFunction: playWithErrorHandlingDoCatch")
playWithErrorHandlingDoCatch()

//_____________________________________________________________
//_____________________________________________________________

// Swift program to demonstrate the working of a
// guard statement having multiple conditions
func checkNumber(num: Int)  {
    // Using Guard For Validation
    guard num >= 1, num < 10 else {
        print("\(num) is greater than or equal to 10")
        return
    }

    print("\(num) is less than 10")
}

func playWithCheckNumber() {
	checkNumber(num: 4)
	checkNumber(num: 20)
}

print("\nFunction: playWithCheckNumber")
playWithCheckNumber()


//_____________________________________________________________
//_____________________________________________________________
// Guard-let Statement


// Swift program to demonstrate the working
// of guard-let statement
func checkString() {
    // str is optional type    
    let someString: String? = "GeeksforGeeks"
    
    // Check whether myString has a value
    guard let myString = someString else {
        print("Invalid type")
        return
    }
    
    // Print if condition results into false
    print("myString: \(myString)")
}

// Calling function
func playWithCheckString() {
	checkString()
}

print("\nFunction: playWithCheckString")
playWithCheckString()


//_____________________________________________________________
//_____________________________________________________________

// Swift program to illustrate the difference between 
// if and guard statement 

// Function having if statement
func checkUsingIf(myString: String) {

    // If statement
    if myString == "GeeksforGeeks" {
        print("GeeksforGeeks and \(myString) are the same.")
        return
    }
    print("GeeksforGeeks and \(myString) are different.")
}

// Function having guard statement
func checkUsingGuard(myString: String)  {

    // Guard statement
    guard myString == "GeeksforGeeks" else {
        print("GeeksforGeeks and \(myString) are different.")
        return
    }
    print("GeeksforGeeks and \(myString) are the same.")
}


func playWithGuardVsIf() {
	// Calling functions by passing a string as a parameter
	checkUsingIf(myString: "GeeksforGeeks")
	checkUsingIf(myString: "Bhuwanesh Nainwal")

	checkUsingGuard(myString: "GeeksforGeeks")
	checkUsingGuard(myString: "Bhuwanesh Nainwal")
}

print("\nFunction: playWithGuardVsIf")
playWithGuardVsIf()


//_____________________________________________________________
//_____________________________________________________________


func getEmail(email: String?) -> String? {
	// Validating Email ID
    guard let input = email, !input.isEmpty  else {
        return nil
    }

    return input + "@somewhere.com"
}

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// https://www.geeksforgeeks.org/swift/swift-gaurd-statement/
// https://www.geeksforgeeks.org/swift/swift-gaurd-statement/

