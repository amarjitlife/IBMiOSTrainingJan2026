
//________________________________________________________________
//________________________________________________________________


func playWithOptionals() {
	var greeting: String? = "Good Evening!"
	// let greetingLength = greeting.count
	// |- error: value of optional type 'String?' must be unwrapped 
	//		to refer to member 'count' of wrapped base type 'String'

	// ?. Is Safe Member Access Operator
	var greetingLength: Int?

	greetingLength = greeting?.count
	// Above Line Is Equivalent To Following Code
	//		Compiler Will Genenate Following Code For The Above Line Of Code
	if greeting != nil {  greetingLength = greeting!.count  }
	else { 	greetingLength = nil  }

	print( greetingLength ?? 99 )

	var something: Int 
	something = greetingLength ?? 99
	// Above Line Is Equivalent To Following Code
	//		Compiler Will Genenate Following Code For The Above Line Of Code
	if greetingLength != nil { something = greetingLength! } else { something = 99 }
	print( something )

	greeting = nil
 	greetingLength = greeting?.count
	print( greetingLength ?? "Unknown" )
}

print("\nFunction: playWithOptionals")
playWithOptionals()


//________________________________________________________________
//________________________________________________________________


struct Person {
	var name: String = ""
	// Person Have Always Residence
    // var residence: Residence
	// Person Can Have Or Can't Have Residence
    var residence: Residence?
}

struct Residence {
    var numberOfRooms = 1
	// Residence Can Have Or Can't Have Phyiscal Address
    var phyicalAddress: Address?
}

struct Address {
	var street: String = "Uknonwn"
	var city: String = ""
	var country: String = ""
}

func playWithOptionalChaining() {
	var gabbar = Person( name: "Gabbar Singh" )

	let ramgrah = Address( street: "Jungles", city: "Ramgrah", country: "India")
	var residence = Residence( numberOfRooms: 4 )

	print( ramgrah )
	print( residence )

	print( gabbar )
	residence.phyicalAddress = ramgrah
	gabbar.residence = residence
	print( gabbar )

	// let gabbarRoomCount = gabbar.residence.numberOfRooms
		// : error: value of optional type 'Residence?' 
		//		must be unwrapped to refer to member 'numberOfRooms' 
		//		of wrapped base type 'Residence'
	let gabbarRoomCount = gabbar.residence?.numberOfRooms
	print( gabbarRoomCount ?? "Unknown" )

	// Optional Chaining
	//		If Any Part Of RHS Expression Becomes nil Than Whole Expression Becomes nil
	let gabbarStreet = gabbar.residence?.phyicalAddress?.street
	print( gabbarStreet ?? "Unknown" )
}

print("\nFunction: playWithOptionalChaining")
playWithOptionalChaining()


//_____________________________________________________________
//_____________________________________________________________


func playWithOptionalChainingWithIfLet() {
	var john = Person()
	john.residence = Residence()
	john.residence?.phyicalAddress = Address()

	if let roomCount = john.residence?.numberOfRooms {
	    print("John's residence has \(roomCount) room(s).")
	} else {
	    print("Unable to retreive the number of rooms.")
	}

	if let street = john.residence?.phyicalAddress?.street {
	    print("Jack's street name is \(street).")
	} else {
	    print("Unable to retrieve the address.")
	}
}

print("\nFunction: playWithOptionalChainingWithIfLet")
playWithOptionalChainingWithIfLet()

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")


//________________________________________________________________
// Complete This Article
//
// https://www.geeksforgeeks.org/swift/optional-chaining-in-swift/
//________________________________________________________________


//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

