//_____________________________________________________________
//_____________________________________________________________

// Functions Have Type
// Following Functions sum And sub Function Type Is As Follows
// Function Type : (Int, Int) -> Int
func sum( x: Int, y: Int ) -> Int { return x + y }
func sub( x: Int, y: Int ) -> Int { return x - y }

// Higher Order Functions
//		Functions Which Takes And/Or Returns Functions 

// Polymorphic Function
// Using Mechanism 
//		1. By Passing Function To A Function

// Following calcualtor Function Type Is As Follows
// Function Type : 
//		( Int, Int, (Int, Int) -> Int ) -> Int
func calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation( x, y )
}

func playWithCalculator() {
	let a: Int = 30
	let b: Int = 20

	// Passing a, b and sum Function To Function
	var result = calculator( x: a, y: b, operation: sum ) // Configuring With sum
	print("Result : ", result )

	// Passing a, b and sub Function To Function
	result = calculator( x: a, y: b, operation: sub ) 	// Configuring With sub
	print("Result : ", result )

	// Closure/Lambas Exressions
	let sumClosure = { (x: Int, y: Int) -> Int in return x + y }
	let subClosure = { (x: Int, y: Int) -> Int in return x - y }

	// Passing a, b and sumClosure Closure To Function
	result = calculator( x: a, y: b, operation: sumClosure )
	print("Result : ", result )

	// Passing a, b and subClosure Closure To Function
	result = calculator( x: a, y: b, operation: subClosure )
	print("Result : ", result )

	result = calculator( x: a, y: b, operation: { (x: Int, y: Int) -> Int in return x + y } )
	print("Result : ", result )

	result = calculator( x: a, y: b, operation: { 
		(x: Int, y: Int) -> Int in return x + y 
	} )	
	print("Result : ", result )

	result = calculator( x: a, y: b ) { 
		(x: Int, y: Int) -> Int in return x + y 
	}
	print("Result : ", result )

	result = calculator( x: a, y: b ) { 
		(x, y) in return x + y 
	}
	print("Result : ", result )

	result = calculator( x: a, y: b ) { 
		(x, y) in x + y 
	}
	print("Result : ", result )

	result = calculator( x: a, y: b ) { 
		$0 + $1 
	}
	print("Result : ", result )

	result = calculator( x: a, y: b, operation: + ) 
	print("Result : ", result )

}

print("Function: playWithCalculator")
playWithCalculator()

//_____________________________________________________________
//_____________________________________________________________

func playWithClosuresSyntaxes() {

	let names = ["Ding", "Dong", "Ting", "King", "Tong", "Kong", "Ping"]
	func backwards(firstString: String, secondString: String) -> Bool {
		return firstString > secondString
	}
	func forwards(firstString: String, secondString: String) -> Bool {
		return firstString < secondString
	}

	print(names)
	var backward = names.sorted(by: backwards)
	print("Decending Order: ", backward)

	var forward = names.sorted(by: forwards)
	print("Acending Order : ",forward)

	// Closures/Lambdas
	let backwards1 = { (first: String, second: String) -> Bool in return first > second }
	let forwards1  = { (first: String, second: String) -> Bool in return first < second }

	print(names)
	backward = names.sorted(by: backwards1)
	print("Decending Order: ", backward)

	forward = names.sorted(by: forwards1)
	print("Acending Order : ",forward)

	forward = names.sorted(by: { (first: String, second: String) -> Bool in 
		return first < second 
	} )
	print("Acending Order : ",forward)

	forward = names.sorted(by: { (first, second) -> Bool in 
		return first < second 
	} )
	print("Acending Order : ",forward)

	forward = names.sorted(by: { (first, second) in first < second } )
	print("Acending Order : ",forward)

	forward = names.sorted(by: { $0 < $1 } )
	print("Acending Order : ",forward)

	forward = names.sorted(by:  <  )
	print("Acending Order : ",forward)

	forward = names.sorted { $0 < $1 }  // Trailing Lamdba
	print("Acending Order : ",forward)

	forward = names.sorted { (first, second) in first < second }
	print("Acending Order : ",forward)
}

print("\nFunction: playWithClosuresSyntaxes")
playWithClosuresSyntaxes()

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

