
//_____________________________________________________________
//_____________________________________________________________

// Automatic Reference Counting
class Person {
    let name: String
    
    init(name: String) {
        self.name = name
        print("\(name) is being initialized")
    }

    deinit {
        print("\(name) is being deinitialized")
    }
}

var reference1: Person?
var reference2: Person?
var reference3: Person?

reference1 = Person(name: "John Appleseed")     // Object.referenceCount += 1
print( reference1?.name ?? "Uknonwn" )
// reference1 = nil

reference2 = reference1    // Object.referenceCount += 1
reference3 = reference1    // Object.referenceCount += 1

reference2 = nil    // Object.referenceCount -= 1
reference1 = nil    // Object.referenceCount -= 1
reference3 = nil    // Object.referenceCount -= 1

// When Object References Count Becomes Zero 
//	- It's deinit Called and The Object Get Deallocated


//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

