

//_____________________________________________________________
//
// Initialization
//_____________________________________________________________

// Initialization is the process of preparing an instance 
//		of a class, structure, or enumeration for use. 
//		This process involves setting an initial value for each stored property 
//		on that instance and performing any other setup or initialization 
//		that is required before the new instance is ready for use.

// Classes and structures must set all of their stored properties 
//		to an appropriate initial value by the time an instance of 
//		that class or structure is created. 
// Stored properties cannot be left in an indeterminate state.

// You can set an initial value for a stored property within an initializer, 
//		or by assigning a default property value 
//		as part of the property’s definition.

// NOTE: When you assign a default value to a stored property, 
//		or set its initial value within an initializer, 
//		the value of that property is set directly, without calling any property observers.

// Initializers are called to create a new instance of a particular type. 
//		In its simplest form, an initializer is like 
//		an instance method with no parameters, written using the init keyword:

//_____________________________________________________________


struct Fahrenheit {
	var temperature: Double

	init() {
		temperature = 32.0
	}
}

func playWithInitialiser() {
	let fahrenheit = Fahrenheit()
	print("Default Temperature : \(fahrenheit.temperature)° Fahrenheit")
	print( fahrenheit )
}

print("\nFunction: playWithInitialiser")
playWithInitialiser()

//_____________________________________________________________
//_____________________________________________________________

// Customizing Initialization
// Initialization Parameters

struct Celsius {
	var temperatureInCelsius: Double = 0.0

	// Overloading Initiliser/Constructor Based On Parameter Name
	init(fromFahrenheit fahrenheit: Double) {
		temperatureInCelsius = (fahrenheit - 32) / 1.8
	}

	init(fromKelvin kelvin: Double) {
		temperatureInCelsius = kelvin - 273.15
	}
}

func playWithInitialiserOverloading() {
	let boilingPointOfWater 	= Celsius(fromFahrenheit: 212.0)
	let freezingPointOfWater 	= Celsius(fromKelvin: 273.15)
	print( boilingPointOfWater )
	print( freezingPointOfWater )
}

print("\nFunction: playWithInitialiserOverloading")
playWithInitialiserOverloading()

//_____________________________________________________________
//_____________________________________________________________

// Local/Internal and External Parameter Names

struct Color {
	let red, green, blue: Double

	// Overloading Initiliser/Constructor 
	//		Based On Parameter Name and Parameter Types and Numbers    
	init(red: Double, green: Double, blue: Double) {
		self.red   = red
		self.green = green
		self.blue  = blue
	}

	init(white: Double) {
		red     = white
		green   = white
		blue    = white
	}
}

func playWithExternalAndInternalMethodParameters() {
	let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
	let halfGray = Color(white: 0.5)
	print( magenta )
	print( halfGray )
	// let verGreen = Color(0.0, 1.0, 0.0)
	// Compile time error because external names for parameters were omitted
}


print("\nFunction: playWithExternalAndInternalMethodParameters")
playWithExternalAndInternalMethodParameters()


//_____________________________________________________________
//_____________________________________________________________

// Initializer Parameters Without External Names
// Overloading Initiliser/Constructor 
//		Based On Parameter Name  

struct Celsius2 {
	var temperatureInCelsius: Double = 0.0

	init(fromFahrenheit fahrenheit: Double) {
		temperatureInCelsius = (fahrenheit - 32) / 1.8
	}

	init(fromKelvin kelvin: Double) {
		temperatureInCelsius = kelvin - 273.15
	}

	init(_ celsius: Double) {
		temperatureInCelsius = celsius
	}
}

func playWithInitialiserInternalAndExternalParameters() {
	let bodyTemperature1 = Celsius2(37.0)
	print( bodyTemperature1 )

	let bodyTemperature2 = Celsius2(fromFahrenheit: 98.6 )
	print( bodyTemperature2 )

	let bodyTemperature3 = Celsius2(fromKelvin: 310.15)
	print( bodyTemperature3 )
}

print("\nFunction: playWithInitialiserInternalAndExternalParameters")
playWithInitialiserInternalAndExternalParameters()


//_____________________________________________________________
//_____________________________________________________________

// Class Having Optional Property

class SurveyQuestion {
	var text: String
	// Optional Property Member
	//		By Default Initialised To nil Value
	var response: String?

	// Initialser With One Parameter
	init( text: String ) { 
		self.text = text 
	}
	
	func ask() { 
		print( text ) 
	}
}

func playWithClassOptionalProperty() {
	let cheeseQuestion = SurveyQuestion( text: "Do you like cheese?" )
	cheeseQuestion.ask() 

	// Approach 01
	// if cheeseQuestion.response != nil {
	// 		print( cheeseQuestion.response! )
	// } else { 
	// 		print("Nil Value Found") 
	// }

	// Approach 02
	if let response = cheeseQuestion.response  {
		print( "Response: \(response)" )
	} else { 
		print("Nil Value Found") 
	}

	// Approach 03
	// ?? Followed By Default Value
	//		If Value Before ?? Becomes nil Than Default Value Returned
	print( cheeseQuestion.response ?? "Unknown" ) 

	cheeseQuestion.response = "Yes, I do like cheese"

	// Approach 01
	// if cheeseQuestion.response != nil {
	// 		print( cheeseQuestion.response! )
	// } else { 
	// 		print("Nil Value Found") 
	// }

	// Approach 02
	if let response = cheeseQuestion.response  {
		print( "Response: \(response)" )
	} else { 
		print("Nil Value Found") 
	}

	// Approach 03
	// ?? Followed By Default Value
	//		If Value Before ?? Becomes nil Than Default Value Returned
	print( cheeseQuestion.response ?? "Unknown" ) // ?? Followed By Default Value
}

print("\nFunction: playWithClassOptionalProperty")
playWithClassOptionalProperty()

//_____________________________________________________________
//_____________________________________________________________

// In Swift 
// For Structures
// 		By Default Compiler Will Generate Memberwise Initialser 
//				With Default Parameter Values If You Don't Provide Initialiser
//
// For Classes
// 		By Default Compiler Will Generate Default Intialiser 
//			Without Any Parameter If You Don't Provide Default Initialiser

struct ShoppingListStruct {
	// Optional Members Get Intialised To nil By Default
	var name: String? 
	var quantity 	= 1
	var purchased 	= false

	// Compiler Will Generate Following Memberwise Intialiser If You Don't Provide
	// Providing Custom Memberwise Initialser
	// init( name: String? = nil, quantity: Int = 1, purchased: Bool = false ) {
	// 		print( "Custom Memberwise Initialser Called..." )
	// 		self.name = name
	// 		self.quantity = quantity
	// 		self.purchased = purchased
	// }
}

class ShoppingListClass {
	// Optional Members Get Intialised To nil By Default
	var name: String? 
	var quantity 	= 1
	var purchased 	= false
	// For Swift Classes
	// Compiler Will Generate Default Intialiser Without Any Parameter 
	//		If You Don't Provide Default
	// init( ) {
	// 		print( "Custom Default Initialser Called..." )
	// 		self.name = nil
	// 		self.quantity = 1
	// 		self.purchased = false
	// }

	func description() { print(name ?? "Unknown", quantity, purchased) }
}

func playWithInitialisers() {
				// Using Memerwise Initialser
	let item1 = ShoppingListStruct( name: "Amul Butter", quantity: 4, purchased: true )
	print( item1 )
				// Using Memerwise Initialser : Will Initial All Members With Default Values
	let item2 = ShoppingListStruct()
	print( item2 )

	let item3 = ShoppingListStruct( name: "Amul Cheese" )
	print( item3 )

	let item4 = ShoppingListStruct( name: "Amul Cheese", purchased : true )
	print( item4 )

	let item22 = ShoppingListClass()
	item22.description()

	// let item11 = ShoppingListClass( name: "Amul Butter", quantity: 4, purchased: true )
	// print( item11 )
	// let item33 = ShoppingListClass( name: "Amul Cheese" )
	// print( item33 )
	// let item44 = ShoppingListClass( name: "Amul Cheese", purchased : true )
	// print( item44 )
}

print("\nFunction: playWithInitialisers")
playWithInitialisers()


//_____________________________________________________________
//_____________________________________________________________

struct Size  {  var width = 0.0, height = 0.0 }
struct Point {	var x = 0.0, y = 0.0 }

struct Rectangle {
	var origin = Point()
	var size = Size()

	//Overloading Initialisers
	init() { } 
	
	init(origin: Point, size: Size) {
		self.origin = origin
		self.size = size
	}

	init(center: Point, size: Size) {
		let originX = center.x - (size.width / 2)
		let originY = center.y - (size.height / 2)
		self.init(origin: Point(x: originX, y: originY), size: size)
	}
}

func playWithRectangle() {
	let basicRect = Rectangle() // Rect(origin: Point(), size: Size())
	print(basicRect)

	let originRect = Rectangle(origin: Point(x: 2.0, y: 2.0), size: Size(width: 5.0, height: 5.0))
	print(originRect)

	let centerRect = Rectangle(center: Point(x: 4.0, y: 4.0), size: Size(width: 3.0, height: 3.0))
	print(centerRect)
}

print("\nFunction: playWithRectangle")
playWithRectangle()


//_____________________________________________________________
//_____________________________________________________________


class Vehicle {
	var numberOfWheels = 0
	var description: String {
		return "Something"
		// return "\(numberOfWheels) wheel(s)"
	}

	init() {  
		print("Constructor: Vehicle")
		//....
		print("Constructor: Vehicle - Completed")
	}
}

// let vehicle = Vehicle()
// print("Vehicle: \(vehicle.description)")

class Bicycle: Vehicle {
	override init() {
		print("Constructor: Bicycle")
		super.init() // Parent Class Initialiser Call
		numberOfWheels = 2
		print("Constructor: Bicycle - Completed")
	}
}

func playWithInitialiserCallsInInheritance() {
	let bicycle = Bicycle()
	print("Bicycle: \(bicycle.description)")
}

print("\nFunction: playWithInitialiserCallsInInheritance")
playWithInitialiserCallsInInheritance()


//_____________________________________________________________
//_____________________________________________________________

class Human {
	var firstName = ""
	var middleName = ""
	var lastName = ""

	// Designated Initialser : Which Initialises Object Fully
	//		Initialisation Logic Is At One Place
	init( firstName: String, middleName: String, lastName: String ) {
		self.firstName = firstName
		self.middleName = middleName
		self.lastName = lastName
		print("Designated Initialser : Which Initialises Object Fully Called...")
	}

	// Initialer For Convenience Purpose
	convenience init( firstName: String ) {
		// Convenience Initialser - Calls Designated Initialer
		self.init( firstName: firstName, middleName: "", lastName: "")
	}

	convenience init( firstName: String, lastName: String ) {
		// Convenience Initialser - Calls Designated Initialer
		self.init( firstName: firstName, middleName: "", lastName: lastName )
	}

	func description() { print( firstName + " " + middleName + " " + lastName ) } 
}

func playWithHumanInitialisers() {
	let gabbar1 = Human(firstName: "Gabbar", middleName: "", lastName: "Singh" )
	gabbar1.description()

	let gabbar2 = Human(firstName: "Gabbar" )
	gabbar2.description()

	let gabbar3 = Human(firstName: "Gabbar", lastName: "Singh" )
	gabbar3.description()
}

print("\nFunction: playWithHumanInitialisers")
playWithHumanInitialisers()

//_____________________________________________________________
//_____________________________________________________________

// In Swift
// 	Convenince Initialisers Should Call Designated Initialsers Within Class
//	Designated Initialisers In Child Class Call Designated Initialers In Parent Class

class Food {
	var name: String
	// Food Class Designated Initialser
	init(name: String) {
		self.name = name
	}

	convenience init() {
		// Calling Food Class Designated Initialser
		self.init(name: "[Unnamed]")
	}
}

class RecipeIngredient: Food {
	var quantity: Int

	// RecipeIngredient Class Designated Initialser
	// 		Calling Food Class Designated Initialser
	init(name: String, quantity: Int) {
		self.quantity = quantity
		super.init(name: name)
	}

	override convenience init(name: String) {
		// Calling RecipeIngredient Class Designated Initialser
		self.init(name: name, quantity: 1)
	}
}

func playWithConvenienceAndDesignatedInitialisers() {
	let namedMeat = Food(name: "Bacon")
	let mysteryMeat = Food()
	print( namedMeat.name )
	print( mysteryMeat.name )

	let oneMysteryItem = RecipeIngredient()
	let oneBacon = RecipeIngredient(name: "Bacon")
	let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

	print( oneMysteryItem.name )
	print( oneBacon.name )
	print( sixEggs.name )
}


print("\nFunction: playWithConvenienceAndDesignatedInitialisers")
playWithConvenienceAndDesignatedInitialisers()

//_____________________________________________________________
//_____________________________________________________________

class Animal {
    let species: String
    
    init(species: String) { // Constructor
    	print("Initaliser Called")
        self.species = species
    }
    
    deinit { 				// Distructor
    	print("Deninitaliser Called")
    }
}

func playWithDeinitialiser() {
	var someAnimal: Animal? = Animal(species: "Lion")

	print(someAnimal ?? "Unknown")

	someAnimal = nil
	print(someAnimal ?? "Unknown")	
}

print("\nFunction: playWithDeinitialiser")
playWithDeinitialiser()

//_____________________________________________________________
//_____________________________________________________________


struct Animal1 {
    let species: String
    
    // init Means Initialiser Cann't Return nil Object
    init(species: String) {
        self.species = species
    }
}

struct Animal2 {
    let species: String

	// Failable Initialiser/Constructor
	//		Which Can Return Either Valid Object 
	//		Or Invalid/No Object It Means Returning nil Value
    // init? Marking Means Initialiser Can Return nil Object
    init?(species: String) { 
    	//					Returning Nil
        if species.isEmpty { return nil }
        self.species = species
    }
}

func playWithInitialiserReturningNil() {
	let someCreature1: Animal1 = Animal1(species: "Giraffe")
	print(someCreature1)

	let someCreature2: Animal2? = Animal2(species: "Giraffe")
	print(someCreature2 ?? "Unknown")
}

print("\nFunction: playWithInitialiserReturningNil")
playWithInitialiserReturningNil()

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

