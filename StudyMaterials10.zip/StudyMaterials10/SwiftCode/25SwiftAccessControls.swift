
//_____________________________________________________________
//_____________________________________________________________

/*

// READ FOLLOWING ARCTICLES AND EXPERIMENT CODE EXAMPLES

	https://www.kodeco.com/books/swift-cookbook/v1.0/chapters/1-understand-access-control-levels-in-swift
	https://www.kodeco.com/books/swift-cookbook/v1.0/chapters/2-use-private-access-control-in-swift
	https://www.kodeco.com/books/swift-cookbook/v1.0/chapters/3-use-file-private-access-control-in-swift
	https://www.kodeco.com/books/swift-cookbook/v1.0/chapters/4-use-internal-access-control-in-swift
	https://www.kodeco.com/books/swift-cookbook/v1.0/chapters/5-use-public-access-control-in-swift

*/

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

