
//_____________________________________________________________
//_____________________________________________________________

class IntStack {
    var items = [Int]()
    
    func push(item: Int) {
        items.append(item)
    }
    
    func pop() -> Int {
        return items.removeLast()
    }
}

func playWithIntStack() {
	let intstack = IntStack()
	intstack.push(item: 10)
	intstack.push(item: 20)
	intstack.push(item: 30)
	print(intstack.pop())
	print(intstack.pop())
}

print("\nFunction: playWithIntStack")
playWithIntStack()

//_____________________________________________________________
//_____________________________________________________________

class StringStack {
    var items = [String]()
    
    func push(item: String) {
        items.append(item)
    }
    
    func pop() -> String {
        return items.removeLast()
    }
}

func playWithStringStack() {
	let stack = StringStack()
	stack.push(item: "Ding")
	stack.push(item: "Dong")
	stack.push(item: "Ting")
	print(stack.pop())
	print(stack.pop())
}

print("\nFunction: playWithStringStack")
playWithStringStack()

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

struct Human {
	var name: String = ""
	var age: Int = 0
}

class HumanStack {
    var items = [Human]()
    
    func push(item: Human) {
        items.append(item)
    }
    
    func pop() -> Human {
        return items.removeLast()
    }
}

func playWithHuamnStack() {
	let stack = HumanStack()
	stack.push(item: Human( name: "Gabbar Singh", age: 30 ))
	stack.push(item: Human( name: "Jay", age: 27 ) )
	stack.push(item: Human( name: "Veeru", age: 28) )
	stack.push(item: Human( name: "Basanti", age: 25) )

	print(stack.pop())
	print(stack.pop())
}

print("\nFunction: playWithHuamnStack")
playWithHuamnStack()


//_____________________________________________________________
//_____________________________________________________________

//Generic Stack
//	Template Of Code
//		Compiler Will Generate By Substituting T Type Placeholer With Type

class Stack<T> {
    var items = [T]()
    
    func push(item: T) {
        items.append(item)
    }
    
    func pop() -> T {
        return items.removeLast()
    }
}

func playWithGenericStack() {
	// T Will Be Sustituted With Int Type
	let intstack = Stack<Int>()
	intstack.push(item: 10)
	intstack.push(item: 20)
	intstack.push(item: 30)
	print(intstack.pop())
	print(intstack.pop())

	// T Will Be Sustituted With String Type
	let stringstack = Stack<String>()
	stringstack.push(item: "Ding")
	stringstack.push(item: "Dong")
	stringstack.push(item: "Ting")
	print(stringstack.pop())
	print(stringstack.pop())

	// T Will Be Sustituted With Human Type
	let stack = Stack<Human>()
	stack.push(item: Human( name: "Gabbar Singh", age: 30 ))
	stack.push(item: Human( name: "Jay", age: 27 ) )
	stack.push(item: Human( name: "Veeru", age: 28) )
	stack.push(item: Human( name: "Basanti", age: 25) )

	print(stack.pop())
	print(stack.pop())

	let doublestack = Stack<Double>()
	doublestack.push(item: 10.10 )
	doublestack.push(item: 20.20 )
	doublestack.push(item: 30.30 )
	print(doublestack.pop())
	print(doublestack.pop())
}

print("\nFunction: playWithGenericStack")
playWithGenericStack()

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

