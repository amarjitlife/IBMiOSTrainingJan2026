
//_______________________________________________________________

class Human {
	String name; 
	Human( String name ) {
		this.name = name;
	}
}

//_______________________________________________________________

class Experiments {

	//___________________________________________________________
	//___________________________________________________________

	public static void printArray( int[] numbers ) {
		System.out.println();
		for ( int i = 0 ; i < numbers.length ; i++ ) {
			System.out.print( " " + numbers[i] );
		}
	}

	public static void doChange( int[] a ) {
		for ( int i = 0 ; i  < a.length ; i++ ) {
			a[i] = 99;
		}
	}

	public static void playWithArrays() {
		int[] a = { 10, 20, 30, 40, 50 };
		printArray( a )	;	
		doChange( a );
		printArray( a );
	}

	//___________________________________________________________
	//___________________________________________________________
	
	// class Human {
	// 		String name; 
	// 		Human( String name ) {
	// 			this.name = name;
	// 		}
	// }

	// In Java
	// 		All Objects Are Passed By Reference
	public static void doChange( Human h ) {
		h.name = "Gabbar Singh";
	}

	public static void doChangeMore( Human h ) {
		h = new Human("Gabbar Singh");
	}

	public static void playWithHuman() {
		Human human = new Human( "Unknown" );
		System.out.println( human.name );
		
		doChange( human );
		System.out.println( human.name );

		human.name = "Unknown";
		System.out.println( human.name );
		
		doChangeMore( human );
		System.out.println( human.name );
	}

	//___________________________________________________________
	//___________________________________________________________


	public static void playWithNullability() {
		String greeting  	= new String("Good Morning!");
		Integer number 		= new Integer( 999 );
		Human ntr 			= new Human("Nandamuri Taraka Ramarao");

		System.out.println( greeting );
		System.out.println( greeting.toUpperCase() );

		System.out.println( number );
		System.out.println( ntr.name );
		// In Java By Default Every Object Is Nullable
		//			You Can Assign null Value To Every Object
		greeting	= null;
		number 		= null;
		ntr.name 	= null;

		System.out.println( greeting );
		System.out.println( number );
		System.out.println( ntr.name );
	
		System.out.println( "Coverting To Upper Case..." );

		// System.out.println( greeting.toUpperCase() );
		// Exception in thread "main" java.lang.NullPointerException: Cannot invoke "String.toUpperCase()" because "<local0>" is null
		// 	at Experiments.playWithNullability(Experiments.java:36)
		// 	at Experiments.main(Experiments.java:41)

		// Good Programmer Should Write Code As Follows
		if (greeting != null) {
			System.out.println( greeting.toUpperCase() );
		} else {
			System.out.println( "Invalid Value: Greeting is null...");
		}
	}

	//___________________________________________________________
	//___________________________________________________________

	public static void main( String[] args ) {
		System.out.println("\n\nFunction : playWithNullability");
		playWithNullability();

		System.out.println("\n\nFunction : playWithArrays");
		playWithArrays();

		System.out.println("\n\nFunction : playWithHuman");
		playWithHuman();

		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
	}
}

//_______________________________________________________________
//
//
//_______________________________________________________________

// print("\nFunction: ")

//_______________________________________________________________
//
//
//_______________________________________________________________

// print("\nFunction: ")

