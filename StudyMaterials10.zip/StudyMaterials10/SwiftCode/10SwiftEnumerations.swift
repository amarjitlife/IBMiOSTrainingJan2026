
//_____________________________________________________________
//_____________________________________________________________

/*
enum CompassPoint {
	case North
	case South
	case East
	case West
}

func playWithCompassPointEnum() {
	var direction: CompassPoint = CompassPoint.North

	direction = .East

	switch direction {
		case .North:
			print("Travel To North")
		case .South:
			print("Travel To South")
		case .East:
			print("Travel To East")
		case .West:
			print("Travel To West")
		// default:
		// 	print("Travel To Unknown Direction")
	}

	print(direction)
}


// Prints "Watch out for penguins".

print("\nFunction: playWithCompassPointEnum")
playWithCompassPointEnum()
*/

//_____________________________________________________________
//_____________________________________________________________

enum CompassPoint {
    case north
    case south
    case east
    case west
}

func playWithCompassPointEnum() {
	var directionToHead = CompassPoint.south

	switch directionToHead {
	case .north:
	    print("Lots of planets have a north")
	case .south:
	    print("Watch out for penguins")
	case .east:
	    print("Where the sun rises")
	case .west:
	    print("Where the skies are blue")
	}
}

print("\nFunction: playWithCompassPointEnum")
playWithCompassPointEnum()

//_____________________________________________________________
//_____________________________________________________________

enum Planet: Int {
    case Mercury = 10, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune, Others
}

func playWithPlanetEnum() {
	let somePlanet = Planet.Earth
	switch somePlanet {
		case .Earth:
		    print("Mostly Harmless")
		default:
		    print("Not a safe place for humans")
	}

	print(somePlanet)
	print(Planet.Earth.rawValue)
}

print("\nFunction: playWithPlanetEnum")
playWithPlanetEnum()

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")
