

//_____________________________________________________________
//_____________________________________________________________

func hello() {
	print("Ding Dong...")
}
hello()

func sayHelloWorld() -> String {
	return "Hello World!"
}
print(sayHelloWorld())

func sayHello( personName: String ) -> String {
	let greeting = "Hello " + personName + "!"
	return greeting
}
print( sayHello( personName: "Katrina Kaif"))
// print( sayHello( "Katrina Kaif"))

func openRangeLength(start: Int, end: Int) -> Int {
	return end - start
}
print( openRangeLength(start: 1, end: 10))

func printAndCount(stringToPrint: String ) -> Int {
	print(stringToPrint)
	return stringToPrint.count
}
print( printAndCount(stringToPrint: "Ting Tong King Kong") )


//_____________________________________________________________
//_____________________________________________________________


func minimumMaximum( numbers: [Int] ) -> (min: Int, max: Int) {
	var currentMin = numbers[0]
	var currentMax = numbers[0]

	for number in numbers {
		if number > currentMax {
			currentMax = number
		} else if number < currentMin {
			currentMin = number
		}
	}
	return (currentMin, currentMax)
}

let bounds = minimumMaximum( numbers : [10, 20, -90, 100, 800, -10, 3, 4, 5, 9])
print(bounds)
print("Minimum Value: \(bounds.0) \nMaximum Value: \(bounds.1)")
print("Minimum Value: \(bounds.min) \nMaximum Value: \(bounds.max)")


//_____________________________________________________________
//_____________________________________________________________

// Hathi Ke Danth: Khaane Ke Aur and Deekhaanee Ke Aur
// Elephant's Teeths: To Show Off and To Eat

// External Parameters
// Internal Parameters

func join(firstString s1: String, secondString s2: String, 
	joinWith joiner: String) -> String {
    return s1 + joiner + s2
}

//var resultString = join(s1: "hello", s2: "world", joiner: ", ") 
var resultString = join(firstString: "hello", secondString: "world", joinWith: ", ") 
print(resultString)

// Other Non Standard Following Code or 3rd Party Library
func joinOther(s1: String, s2: String, joiner: String) -> String {
    return s1 + joiner + s2
}

// Our Own APIs w.r.t. Project Guidelines
func joinStrings(firstString s1: String, secondString s2: String, 
	joinWith joiner: String) -> String {
    return joinOther(s1: s1, s2: s2, joiner: joiner)
}
resultString = joinStrings(firstString: "hello", secondString: "world", joinWith: ", ") 
print(resultString)


//_____________________________________________________________
//_____________________________________________________________

func containCharacter(string: String, searchCharacter: Character ) -> Bool {
	for character in string {
		if character == searchCharacter {  
			return true
		}
	}
	return false
}
let containResult = containCharacter(string: "Wonderful One!", searchCharacter: "O")
print(containResult)


//_____________________________________________________________
//_____________________________________________________________

// Varidiac Argument Mechanism -> Polymorphism
func arithmeticMean(base: Double = 0.0, numbers: Double...) -> Double {
	var total = base
	for number in numbers {
		total = total + number
	}
	return total / Double(numbers.count)
}

var resultMean = arithmeticMean(base: 100, numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print(resultMean)
resultMean = arithmeticMean(numbers: 1, 2, 3, 4, 5, 6)
print(resultMean)
resultMean = arithmeticMean(numbers: 1, 2, 3, 4)
print(resultMean)
let someNumbers: [Double] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

//var resultMean = arithmeticMean(base: 100, numbers: someNumbers)

//_____________________________________________________________
//_____________________________________________________________

// Functions Have Type
// Following Functions sum And sub Function Type Is As Follows
// Function Type : (Int, Int) -> Int
func sum( x: Int, y: Int ) -> Int { return x + y }
func sub( x: Int, y: Int ) -> Int { return x - y }
func mul( x: Int, y: Int ) -> Int { return x * y }

// Function Type : (Int, Int, Int) -> Int
func sum3( x: Int, y: Int, z: Int ) -> Int { return x + y + z }

// Higher Order Functions
//		Functions Which Takes And/Or Returns Functions 

// Following calcualtor Function Type Is As Follows
// Function Type : (Int, Int, (Int, Int) -> Int ) -> Int
func calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation( x, y )
}

func playWithCalculator() {
	let a: Int = 30
	let b: Int = 20

	// Passing a, b and sum Function To Function
	var result = calculator( x: a, y: b, operation: sum )
	print("Result : ", result )

	// Passing a, b and sub Function To Function
	result = calculator( x: a, y: b, operation: sub )
	print("Result : ", result )

	// Passing a, b and sub Function To Function
	result = calculator( x: a, y: b, operation: mul )
	print("Result : ", result )

	// result = calculator( x: a, y: b, operation: sum3 )
	// error: cannot convert value 
	//			of type '(Int, Int, Int) -> Int' 
	// 			to expected argument type '(Int, Int) -> Int'
	// print("Result : ", result )

	// What Is The Type Of something?
	//		It's A Function Type : (Int, Int) -> Int
	let something  = sum
	result = something( a, b )
	print("Result : ", result )

	let something1: (Int, Int) -> Int  = sum
	result = something( a, b )
	print("Result : ", result )

	// What Is The Type Of somethingAgain?
	let somethingAgain = calculator
	result = somethingAgain( a, b, sum )
	print("Result : ", result )

	let somethingAgain1: (Int, Int, (Int, Int) -> Int ) -> Int = calculator
	result = somethingAgain1( a, b, sub )
	print("Result : ", result )

}

print("\nFunction: playWithCalculator")
playWithCalculator()


//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")
