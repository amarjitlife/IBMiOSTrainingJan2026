
//_______________________________________________________________
//
// Questions
//_______________________________________________________________

01. Difference Between Float and Double Types?
02. Is there Long Type In Swift?
03. Is String Class or Something Else In Swift?
04. What Is Hashable Protocol?
05.
06.
07.
08.
09.
10.

//_______________________________________________________________
//
// Assignment :: Exploration and Experiment Assignments
//_______________________________________________________________
// Experiment Type Conversion Idea In
//		Swift/C/C++/Java/Python/TypeScript Languages

print("\nExplicit Type Conversion")

let label = "The Width is: "
let width = 88
// let labelledWidth = label + width
// error: binary operator '+' cannot be applied to operands of type 'String' and 'Int

// Explicit Type Conversion
let labelledWidth = label + String( width )
print( labelledWidth )

let someFloatValue : Float = 10.10
let someDoubleValue : Double = 99.99

// let someValue1 = someFloatValue + someDoubleValue
//  error: binary operator '+' cannot be applied to operands of type 'Float' and 'Double'

let someValue1 = Double( someFloatValue ) + someDoubleValue 
print( someValue1 )

let someValue2 = someFloatValue + Float( someDoubleValue )
print( someValue2 )

let someIntValue1: Int8 	= 100
let someIntValue2: Int16 	= 99

// let someIntValue = someIntValue1 + someIntValue2 
// error: binary operator '+' cannot be applied to operands of type 'Int8' and 'Int16

let someIntValue11 = Int16( someIntValue1 ) + someIntValue2 
print( someIntValue11 )

let someIntValue12 = someIntValue1 + Int8( someIntValue2 )
print( someIntValue12 )
	
//_______________________________________________________________

