
//_______________________________________________________________
//
// Constant, Variables, Initialisation and Types
//_______________________________________________________________
// Experiment Following Ideas In 
//		All Lanugages Swift, C/C++, Java, Python

let maximumNumberOfLoginAttemps = 10
var currentLoginAttempt = 0

var x = 0.0, y = 0.0, z = 0.0

print( maximumNumberOfLoginAttemps )
print( currentLoginAttempt )
print( x, y, z )


// let something1
// `- error: type annotation missing in pattern
// var something2
// `- error: type annotation missing in pattern

// Definitions
let something1 : Int 
var something2 : Double

// print( something1 )
   // |        `- error: constant 'something1' used before being initialized
// print( something2 )
   // |        `- error: constant 'something2' used before being initialized

something1 = 99 	// Initialise Before Usage
print( something1 )
// something1 = 100
   // |            `- error: immutable value 'something1' may only be initialized once

something2 =  88.88 // Initialise Before Usage
print( something2 )


var welcomeMessage: String
welcomeMessage = "Hello"
print( welcomeMessage )

//_______________________________________________________________
//
// Unicode Introduction
//_______________________________________________________________

func playWithUnicodes() {
	// In Swift
	//		Strings Are Unicode String
	//		Each Character In Unicode String Is Unicode Character
	//		Each Unicode Character Have A Number
	//				That Number Is Called Unicode Point
	let नमस्ते = "Namaskar!"
	print( नमस्ते )

	let hello = "नमस्ते"
	print( hello )

	let vaankaam = "வணக்கம்"
	print( vaankaam )

	// Unicode Character “☺” (U+263A)
	let smiley1: Character = "☺" // ☺
	print( smiley1 )

	let smiley2: Character = "\u{263A}" // ☺
	print( smiley2 )

	let writing: Character = "\u{270D}"
	print( writing )

	// Indentifiers Can Also Be Unicode String
	//		Hence Variable, Constant, Functions Name Can Be Unicode Strings
	let π : Float = 3.1415
	print( π )

	let piUnicodeCharacter: Character = "\u{03C0}"
	print( piUnicodeCharacter )
	let firstScalar = piUnicodeCharacter.unicodeScalars.first
	print( firstScalar?.value  ?? "Uknonwn") // 960 In Base 10 = 3C0 In Base 16

	let வணக்கம் = "Vaankaaam!!!!"
	print( வணக்கம் )

	let 🐶🐮 = "Dog and Cow"
	print( 🐶🐮 )

	let someString = "🐶🐮"
	print( someString )

	print( smiley1, hello, someString ) // Using Separator With Default Value Of " "
	print( smiley1, hello, someString, separator: " ## " ) // Using Seperator " ## "
	print( smiley1, hello, someString, separator: ", " ) // Using Seperator ", "

	// Using Semicolon ; To Separate More Than 1 Line Of Code
	let someString1 = "🐶🐮"  ;  print( someString1 )

	// Single Line Comment
	/* Multiple Line Comment
	First Line
	Second Line...
	*/
}

print("\nFunction: playWithUnicodes")
playWithUnicodes()

//_______________________________________________________________
//
// Print Function Usages
//_______________________________________________________________


func playWithPrintFunctions() {
	let smiley1: Character = "☺" // ☺
	print( smiley1 )

	let hello = "Good Morning!!!"
	print( hello )

	let someString = "🐶🐮"
	print( someString )

	print( smiley1, hello, someString ) // Using Separator With Default Value Of " "
	print( smiley1, hello, someString, separator: " ## " ) // Using Seperator " ## "
	print( smiley1, hello, someString, separator: ", " ) // Using Seperator ", "

	// Using Semicolon ; To Separate More Than 1 Line Of Code
	let someString1 = "🐶🐮"  ;  print( someString1 )

	// Single Line Comment
	/* Multiple Line Comment
	First Line
	Second Line...
	*/

	print( "Hello", "World") // Default separator Is " " and Terminator Is "\n"
	print( " NextString " )
	print( "Hello", "World", separator : " + ") // Default Terminator Is "\n"
	print( " NextString " )
	print( "Hello", "World", separator : " + ", terminator: "")
	print( " NextString " )
}

print("\nFunction: playWithPrintFunctions")
playWithPrintFunctions()


//_______________________________________________________________
//
// Numbers Type and Representations
//_______________________________________________________________


func playWithNumbersTypeAndRepresentations() {
	let decimalInteger = 17 		// Int Type Value In Base 10
	let binaryInteger = 0b10001 	// Int Type Value In Base 2
	let octalInteger = 0o21 		// Int Type Value In Base 8
	let hexadecimalInteger = 0x11 	// Int Type Value In Base 16

	print(decimalInteger)
	print(binaryInteger)
	print(octalInteger)
	print(hexadecimalInteger)

	let decimalDouble = 12.1875
	let exponentDouble = 1.21875e1

	print(decimalDouble)
	print(exponentDouble)

	let oneMillion = 1_000_000
	let justOverOneMillion = 1_000_000.000_000_1
	let paddedDouble = 000123.456

	print(paddedDouble)
	print(oneMillion)
	print(justOverOneMillion)	
}

print("\nFunction: playWithNumbersTypeAndRepresentations")
playWithNumbersTypeAndRepresentations()


//_______________________________________________________________
//
//	Data Type 
//		Have Range Of Values = [ Minimum, Maximum ]
//
// Swift Int Types
//		Signed Ints  Types :  Int8,  Int16,  Int32,  Int64,  Int
//		Unsigned Int Types : UInt8, UInt16, UInt32, UInt64, UInt

// Assume Number Of Bits 	= N
//		Unsigned Int Range 	= [   0, 2^N - 1 ]
//	      Signed Int Range 	= [ - 2^(N-1), 2^(N - 1) - 1 ]
//_______________________________________________________________


func playWithSwiftIntTypesRanges() {
	let minValue = Int8.min //  -128 = - 2^7 
	let maxValue = Int8.max //   127 =   2^7 - 1

	print("Int8 Type")
	print("\tMinimum Value:", minValue)
	print("\tMaximum Value:", maxValue)

	print("UInt8 Type")
	print("\tMinimum Value:", UInt8.min) // 0   = 0
	print("\tMaximum Value:", UInt8.max) // 255 = 2^8 - 1

	print("Int16 Type")
	print("\tMinimum Value:", Int16.min)
	print("\tMaximum Value:", Int16.max)

	print("UInt16 Type")
	print("\tMinimum Value:", UInt16.min)
	print("\tMaximum Value:", UInt16.max)

	print("Int32 Type")
	print("\tMinimum Value:", Int32.min)
	print("\tMaximum Value:", Int32.max)

	print("UInt32 Type")
	print("\tMinimum Value:", UInt32.min)
	print("\tMaximum Value:", UInt32.max)

	print("Int64 Type")
	print("\tMinimum Value:", Int64.min)
	print("\tMaximum Value:", Int64.max)

	print("UInt64 Type")
	print("\tMinimum Value:", UInt64.min)
	print("\tMaximum Value:", UInt64.max)

	print("Int Type")
	print("\tMinimum Value:", Int.min)
	print("\tMaximum Value:", Int.max)

	print("UInt Type")
	print("\tMinimum Value:", UInt.min)
	print("\tMaximum Value:", UInt.max)
}

print("\nFunction: playWithSwiftIntTypesRanges")
playWithSwiftIntTypesRanges()


//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithTypeRangeValues() {
	let some1: Int8 = 127
	// let some2: Int8 = 128
	// `- error: integer literal '128' overflows when stored into 'Int8'
	print( some1 )
	// print( some2 )

	let some3: Int8 = -128
	// let some4: Int8 = -129
	// `- error: integer literal '-129' overflows when stored into 'Int8'
	print( some3 )
	// print( some4 )

	let some5 = 127
	let some6 = some5 + 1
	print( some6 )

	let some55: Int8 = 127
	// let some66: Int8 = some55 + 1  
	// 	`- error: arithmetic operation '127 + 1' (on type 'Int8') results in an overflow
	let some66: Int8 = some55 &+ 1 // &+ Operator Behaves As C + Operator
	print( some66 )

	let threeValue: Int8 = 3
	let pointValue: Float = 0.14159
	// let piValue = threeValue + pointValue
	// |- error: binary operator '+' cannot be applied to operands of type 'Int8' and 'Float'
	let piValue = Float( threeValue ) + pointValue
	print( piValue )

	let twoThousand: UInt16 = 2_000
	let one: UInt8 = 1
	// let twoThousandOne = twoThousand + one 
	// |- error: binary operator '+' cannot be applied to operands of type 'UInt16' and 'UInt8'
	let twoThousandOne = twoThousand + UInt16( one )
	print( twoThousandOne )
}

// Function: playWithTypeRangeValues
// 127
// -128
// 128
// -128

print("\nFunction: playWithTypeRangeValues")
playWithTypeRangeValues()

//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithBooleanValues() {
	// let orangesAreOrange: Bool = true 
	// let turnipsAreDelicious: Bool = false 
	let orangesAreOrange = true 
	let turnipsAreDelicious  = false 

	//if (turnipsAreDelicious) {
	if turnipsAreDelicious || orangesAreOrange {
		print("Tasty Turnips!")
	} else {
		print("Horrible Turnips")
	}

	let i = -10
	if ( i == -10 ) {
		print("Balleee Balleeee")
	} 
	// else { // Dead Code: Code Which Will Never Be Reached/Exectuted 
	// 	print("Oyeee Hoyeeee")
	// }

	if true {
		print("Balleee Balleeeeee!!!")
	}
	// else { // Dead Code: Code Which Will Never Be Reached/Exectuted 
	// 	print("Dead Code!")
	// }
}

print("\nFunction: playWithBooleanValues")
playWithBooleanValues()


//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithTypeAlias() {
	// typealias Creates Alias i.e. Another Name For Type
	typealias AudioSample = UInt16
	let amplitudeValue = AudioSample.min
	print(amplitudeValue)

	let volume : AudioSample = 10
	print( volume )
}

print("\nFunction: playWithTypeAlias")
playWithTypeAlias()

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithTuples() {
	// Type Inference: Right Side is Tuple of (Int, String)
	// Creating Tuple : Tuple Is Associated Values
	//		Creating Tuple With 2 Members With Types Int and String
	// Following Both Lines Are Equivalent
	// Tuple Is Inferred Implicitly From RHS
	let http404Error = (404, "Not Found")
	// let http404Error : (Int, String) = (404, "Not Found")

	let status 	= http404Error.0
	let message = http404Error.1
	print("The Status Code: \(status)") 		//String Extrapolation/Substitution
	print("The Status Message: \(message)")	//String Extrapolation/Substitution

	// Above Code Can Written Shortcut Way Using Unpacking Syntax	
	let (statusCode, statusMessage) = http404Error 	//Unpacking Tuple 
	print("The Status Code: \(statusCode)") 		//String Extrapolation/Substitution
	print("The Status Message: \(statusMessage)")	//String Extrapolation/Substitution

	print("The Status Code: \(http404Error.0)") 		//String Extrapolation/Substitution
	print("The Status Message: \(http404Error.1)")	//String Extrapolation/Substitution

	// Tuple With Exlicitly Type Annotated	
	let http404Error1: (Int, String) = (404, "Not Found")
	print( http404Error1 )
	print("The Status Code: \(http404Error.0)") 		//String Extrapolation/Substitution
	print("The Status Message: \(http404Error.1)") 		//String Extrapolation/Substitution
	
	let (justTheStatusCode, _ ) = http404Error 	// Unpacking Tuple 
	//let (justTheStatusCode, ding, dong ) = http404Error 	// Unpacking Tuple
	// let (justTheStatusCode) = http404Error 	// Unpacking Tuple
	print("The Status Code: \(justTheStatusCode)") 		//String Extrapolation/Substitution


	//Named Tuple
	let http200Status = (statusCode: 200, description: "OK")
	print("The Status Code: \(http200Status.0)") 		//String Extrapolation/Substitution
	print("The Status Message: \(http200Status.1)")	//String Extrapolation/Substitution

	print("The Status Code: \(http200Status.statusCode)") 		//String Extrapolation/Substitution
	print("The Status Message: \(http200Status.description)")	//String Extrapolation/Substitution

	let http200Status1: (statusCode: Int, description: String) = (statusCode: 200, description: "OK")
	print("The Status Code: \(http200Status1.0)") 		//String Extrapolation/Substitution
	print("The Status Message: \(http200Status1.1)")	//String Extrapolation/Substitution

	print("The Status Code: \(http200Status1.statusCode)") 		//String Extrapolation/Substitution
	print("The Status Message: \(http200Status1.description)")	//String Extrapolation/Substitution

}


print("\nFunction: playWithTuples")
playWithTuples()

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithTuplesAgain() {
	// let somethingTuple = ( 999, "Good Evening!" )
	var somethingTuple = ( 999, "Good Evening!" )
	// Createing Tuple of (Int, Int)
	let someTuple1: (Int, Int) = ( 10, 20 )	
	let someTuple2: (Int, String) = ( 111, "Very Good!" )	

	// http404Error = someTuple
	
	print( someTuple1 )
	print( somethingTuple )

	// somethingTuple = someTuple1
	// `- error: cannot assign value of type '(Int, Int)' to type '(Int, String)'

	// somethingTuple = someTuple2
	// `- error: cannot assign to value: 'somethingTuple' is a 'let' constant

	somethingTuple = someTuple2
	print( somethingTuple )

	// let someTuple0 = (10, 20)
	var someTuple0 = (10, 20)

	print( someTuple0 )
	print( someTuple0.0 )
	print( someTuple0.1 )

	someTuple0.0 = 88
	// `- error: cannot assign to property: 'someTuple0' is a 'let' constant
	someTuple0.1 = 99
	// `- error: cannot assign to property: 'someTuple0' is a 'let' constant
	print( someTuple0 )	
}

print("\nFunction: playWithTuplesAgain")
playWithTuplesAgain()

//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithLargeTuples() {
	// let someTuple0 : (Int, Int, Int) = (10, 20, 30, 99, 88)
	// `- error: '(Int, Int, Int, Int, Int)' is not convertible to '(Int, Int, Int)'
	let someTuple0 : (Int, Int, Int, Int, Int) = (10, 20, 30, 99, 88)
	print( someTuple0 )

	let someTuple5: ((Int, Int), (String, String)) = ((10, 20), ("Ding", "Dong"))
	print(someTuple5)
}

print("\nFunction: playWithLargeTuples")
playWithLargeTuples()

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithTuplesUnpacking() {
	let http404Error = (404, "Not Found")
	let (statusCode, statusMessage) = http404Error 	//Unpacking 

	print("The Status Code: \(statusCode)") 		//String Extrapolation/Substitution
	print("The Status Message: \(statusMessage)")	//String Extrapolation/Substitution

	let (justTheStatusCode, _ ) = http404Error 	// Unpacking Tuple 
	print("The Status Code: \(justTheStatusCode)") 		//String Extrapolation/Substitution

	// Following Lines Will Give Compile Time Error!
	// let (justTheStatusCode, ding, dong ) = http404Error 	// Unpacking Tuple
	// let (justTheStatusCode) = http404Error 	// Unpacking Tuple
}

print("\nFunction: playWithTuplesUnpacking")
playWithTuplesUnpacking()


//_______________________________________________________________
//
//
//_______________________________________________________________


func swiftProgrammingQuiz1() {
	// What is The Type Of something1?

	// let something1: ( Int, Int ) = ( ("Ding", 99), 10.10 )
	// `- error: cannot convert value of type '((String, Int), Double)' to specified type '(Int, Int)'

	let something1: ( (String, Int), Double ) = ( ("Ding", 99), 10.10 )
	print( something1 )

	// What is The Type Of something2?
	let something2 = ( (99.99, "Ding"), (10.10, "Dong") )
	print( something2 )


	// What Will Be Output Of Following Code?
	let (some1, some2) = something2
	print( some1 )
	print( some2 )

	// What Will Be Output Of Following Code?
	print( something2.1 )
	print( some2.0 )


	// What Will Be Output Of Following Code?
	print( something2.1.1 )
	print( something2.0.0 )


	// What is The Type Of something3?
	let something3: ( (Int, Int, Int), [Int] ) = ( (10, 20, 30), [100, 200, 3000] )
	print( something3 )


	// What is The Type Of something4?
	let something4: ( [ (Int, Int) ], [String] ) = ( [ (10, 20), (30, 40) ], [ "Ding", "Dong", "Ting", "Tong"] )
	print( something4 )
}

print("\nFunction: swiftProgrammingQuiz1")
swiftProgrammingQuiz1()

// print("\nFunction: ")

//_______________________________________________________________
//
//
//_______________________________________________________________

// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")
// print("\nFunction: ")

