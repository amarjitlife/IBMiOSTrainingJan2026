
import Foundation
//_____________________________________________________________
//_____________________________________________________________

// Defining Structure/Type FixedLengthRange
struct FixedLengthRange {
	// Instance/Object Properties i.e. Accessed Using Object/Instance
	// Mutable Properties
	var firstValue: Int = 0
	var length : Int 	= 0
}

func playWitStructureObjectMutability() {
	// 
	var rangeOfThreeItems: FixedLengthRange = FixedLengthRange( firstValue: 0, length: 3 )
	print( rangeOfThreeItems )
	rangeOfThreeItems.firstValue = 66
	print( rangeOfThreeItems )

	// rangeOfThreeItems1 Becomes Immutable
	//		Hence It's Member Properties Also Treated Immutable
	let rangeOfThreeItems1: FixedLengthRange = FixedLengthRange( firstValue: 10, length: 3 )
	print( rangeOfThreeItems1 )
	// rangeOfThreeItems1.firstValue = 66
	// `- error: cannot assign to property: 'rangeOfThreeItems1' is a 'let' constant
	print( rangeOfThreeItems1 )
}

print("\nFunction: playWitStructureObjectMutability")
playWitStructureObjectMutability()

//_____________________________________________________________
//_____________________________________________________________

struct Point {
	var x = 0.0, y = 0.0
}

struct Size {
	var width = 0.0, height = 0.0
}

// First Rectangle Definition 
// Two Stored Properties : origin And size
//	 	Compiler Will Generate 
//			Getter, Setter And Member Field/Variable

struct Rectangle {
	var origin = Point()
	var size   = Size()
	var center : Point { // Computed Property With Custom Getter And Setter
		get { // Custom Getter
			print("Rectangle: center Getter Called...")
			let centerX = origin.x + ( size.width / 2 )
			let centerY = origin.y + ( size.height / 2 )
			return Point( x: centerX, y: centerY )
		}
		set( newCenter ) { // Custom Setter
			print("Rectangle: center Setter Called...")
			origin.x = newCenter.x - ( size.width / 2 )
			origin.y = newCenter.y - ( size.height / 2 )			
		}
	}

	func distance() -> Double { 
		// return squareRoot( ( origin.x * origin.x ) + ( origin.y * origin.y ) ) 
		return sqrt( ( origin.x * origin.x ) + ( origin.y * origin.y ) ) 
	}
}

struct RectangleAgain {
	var origin = Point()
	var size   = Size()
	var center : Point { // Computed Property With Custom Getter And Setter
		get { // Custom Getter
			print("Rectangle: center Getter Called...")
			let centerX = origin.x + ( size.width / 2 )
			let centerY = origin.y + ( size.height / 2 )
			return Point( x: centerX, y: centerY )
		}
		set { // Custom Setter With Default Argument Name newValue
			print("Rectangle: center Setter Called...")
			origin.x = newValue.x - ( size.width / 2 )
			origin.y = newValue.y - ( size.height / 2 )			
		}
	}

	func distance() -> Double { 
		// return squareRoot( ( origin.x * origin.x ) + ( origin.y * origin.y ) ) 
		return sqrt( ( origin.x * origin.x ) + ( origin.y * origin.y ) ) 
	}
}

func playWithRectangle() {
	let somePoint = Point()
	print( somePoint )

	let someSize = Size()
	print( someSize )

	var square = Rectangle( origin: Point(x: 0.0, y: 0.0), 
							size: Size(width: 10.0, height: 10.0))
	print( square )	
	// Getter Called center.get() 
	let initialCenterPoint = square.center 
	print( initialCenterPoint )
	// Setter Called center.set( Point( x: 15.0, y: 15.0 ) )
	square.center = Point( x: 15.0, y: 15.0 ) 
	print("Square Now: ", square)
	print("Square Origin Now: ", square.origin )
	print("Square Center Now: ", square.center )
	print("Square Distance: ", square.distance() )
}

print("\nFunction: playWithRectangle")
playWithRectangle()

//_____________________________________________________________

// Second Rectangle Definition 
// Two Stored Properties : topLeftCorner And bottomRightCorner
//	 	Compiler Will Generate 
//			Getter, Setter And Member Field/Variable
struct RectangleAlternative {
	var topLeftCorner 		= Point()
	var bottomRightCorner   = Point()
	var size : Size { // Computed Property With Custom Getter And Setter
		get {
			// Write Logic To Calcualate Rectangle Size and Return Size
			return Size() // Returning Dummy Size
		}
		set( newCenter ) {
			// Write Logic To Set Rectangle Size			
		}
	}

	func distance() -> Double { 
		// Write Logic To Calculate Distance...
		return 99.99 // Returning Dummy Data...
	}
}

//_____________________________________________________________
//_____________________________________________________________

// Read only Computed Properties
struct Cuboid {
	// Stored Properties
    var width = 0.0, height = 0.0, depth = 0.0
	// Read Only Computed Properties
    // let volume: Double {
    	// error: 'let' declarations cannot be computed properties
    var volume: Double {
    	get { // Custome Getter Is Provided
    		return width * height * depth
    	}
    }
}

func playWithComputedReadOnlyProperties() {
	let fourByFiveByTwo = Cuboid(width: 4.0, height: 5.0, depth: 2.0)
	print("the volume of fourByFiveByTwo is \(fourByFiveByTwo.volume)")
	//fourByFiveByTwo.volume = 100
}

print("\nFunction: playWithComputedReadOnlyProperties")
playWithComputedReadOnlyProperties()

//_____________________________________________________________
//_____________________________________________________________

class StepCounter {
	// Instance/Object Properties i.e. Accessed Using Object/Instance
	var totalSteps : Int = 0 {
		// Property Observers
		willSet( newTotalSteps) {
			print("StepCounter: willSet Called...")
		}

		didSet {
			// Validation On Property	
			if totalSteps >= 5000 {
				totalSteps = 5000
			} else if totalSteps < 0 {
				totalSteps = 0
			}
			print("StepCounter: didSet Called...")
		}
	}
}

func playWithPropertyObservers() {
	let stepCounter = StepCounter()

	// totalSteps Instance/Object Properties i.e. Accessed Using Object/Instance
	print("Total Steps Defaul Value: ", stepCounter.totalSteps)
	stepCounter.totalSteps = 100
	print("Total Steps After Assignment: ", stepCounter.totalSteps)

	stepCounter.totalSteps = 250
	stepCounter.totalSteps = 10
	print("Total Steps After Assignment: ", stepCounter.totalSteps)
	stepCounter.totalSteps = 4000
	print("Total Steps After Assignment: ", stepCounter.totalSteps)
	stepCounter.totalSteps = 5000
	print("Total Steps After Assignment: ", stepCounter.totalSteps)
	stepCounter.totalSteps = 9000
	print("Total Steps After Assignment: ", stepCounter.totalSteps)
	stepCounter.totalSteps = -90
	print("Total Steps After Assignment: ", stepCounter.totalSteps)
}

print("\nFunction: playWithPropertyObservers")
playWithPropertyObservers()

//_____________________________________________________________
//_____________________________________________________________

// Structure/Type Properties
struct SomeStructure {
	var instanceProperty: String = "Instance Propery Value"
	// Type Level Stored Property
	static var storedTypeProperty = "Some value."
	// Type Level Computed Property
    static var computedTypeProperty: Int {
    	// get {
     	   return 1
    	// }
    }
}

func playWithTypeLevelProperties() {
	// Type Level Properties Access Using Structure/Type Name
	print( SomeStructure.computedTypeProperty )
	print( SomeStructure.storedTypeProperty )

	let someObject = SomeStructure()
	print( someObject )
	// print( someObject.computedTypeProperty )
	// print( someObject.storedTypeProperty )
	print( someObject.instanceProperty )
}

print("\nFunction: playWithTypeLevelProperties")
playWithTypeLevelProperties()

// BEST PRACTICES
	// static Members 
	// Recommended: USED IN RAREST RARE CASE


//_____________________________________________________________
//_____________________________________________________________


// __________________________________________________________
// __________________________________________________________

// Enumeration/Type Properties
enum SomeEnumeration {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 6
    }
}

// Class/Type Properties
class SomeClass {
	var instanceProperty: String = "Instance Propery Value"
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 27
    }

    class var overrideableComputedTypeProperty: Int {
        return 107
    }
}

func playWithTypeLevelPropertiesAgain() {
	print(SomeEnumeration.computedTypeProperty)         // prints "6"
	print(SomeClass.computedTypeProperty)               // prints "27"

	let someObject = SomeClass()
	print( someObject.instanceProperty )
}

print("\nFunction: playWithTypeLevelPropertiesAgain")
playWithTypeLevelPropertiesAgain()

//_____________________________________________________________
//_____________________________________________________________

class DataImporter {
	let fileName = "data.txt" // Some File

	init() {
		print("Creating DataImporter Object...")
	}
}

class DataManager {
	// var importer = DataImporter()
	lazy var importer = DataImporter()
	// Assume data Will Be Poplulated After Reading From File
 	var data = [String]()

 	func readData() -> [String] {
 		print("Reading Data From: ", importer.fileName )
 		//Assume Read Data File And Populated data With That...
 		data += ["Ding", "Dong", "Ting", "Tong", "Ming", "Mong"]
 		return data
 	}
}

func playWithDataManager() {
	let manager 	= DataManager()
	let dataRead 	= manager.readData()
	print("Read Data: ", dataRead ) 
}

print("\nFunction: playWithDataManager")
playWithDataManager()

// Function: playWithDataManager
// Creating DataImporter Object...
// Reading Data From:  data.txt
// Read Data:  ["Ding", "Dong", "Ting", "Tong", "Ming", "Mong"]

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")
