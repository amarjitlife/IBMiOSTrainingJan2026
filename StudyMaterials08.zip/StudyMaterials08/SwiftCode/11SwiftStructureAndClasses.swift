
//_____________________________________________________________
//_____________________________________________________________

// Compiler Will Generate Following Things For Structure
//		1. Generate Getters and Setters For Each Property
//			Getter and Setter Name Will Be Same As Property Name
//			Note: 
//			For Immtuablable Property (let) Only Getter Generated
//			For Muablable Property (var) Both Getter and Setter Generated
//		2. Generate Memberwise Initialiser ( Constructor )
//			 	Initiliser ( Contructor ) Which Will Initialise All Member Properties

// Structure Are Associatvve Types
//		Associate Multiple Type Of Data Together
struct Resolution {
//	Two Member Properties : width And height 
	var width 	= 0 // Default Values
	var height 	= 0 // Default Values
}

func playWithStructureObject() {
	var resolution = Resolution() // Resolution( width: 0, height : 0 )
	print( resolution )

	print( resolution.width ) // resolution.width   - Getter Call width Property
 	print( resolution.height )

	resolution.width 	= 1920 // resolution.width  - Setter Call width Property
	resolution.height 	= 1080
	print( resolution )

	let resolution1 = Resolution() // Resolution( width: 0, height : 0 )
	print( resolution1 )
	// resolution1.width 	= 1920 // resolution.width  - Setter Call width Property
    // |              `- error: cannot assign to property: 'resolution1' is a 'let' constant
	// resolution1.height 	= 1080
	// |              `- error: cannot assign to property: 'resolution1' is a 'let' constant
	print( resolution1 )
	let vga = Resolution( width: 640, height : 480 )
	print( vga )
	print( vga.width )
	print( vga.height )
}

print("\nFunction: playWithStructureObject")
playWithStructureObject()

//_____________________________________________________________
//_____________________________________________________________

// Value Types
//		Structures, Arrays, Tuples, Enum, Int, Float, Double, String etc.. 
//		All Above Are Value Types In Swift

// Reference Types
//		Classes, Closures And Functions Are Reference Types In Swift
//		All Above Are Reference Types In Swift

func playWithValueTypes() {
	// Structures Are Value Type
	print( "Experiment : Structure Value Type" ) 
	var resolution = Resolution( width: 640, height : 480 )
	// Object/Value Assignment i.e. Full Object/Value Get Copied
	let resolutionCopy = resolution

	print( resolution )
	print( resolutionCopy )

	resolution.width 	= 1920
	resolution.height 	= 1080

	print( resolution )
	print( resolutionCopy )

	// Arrays Are Value Type 
	print( "Experiment : Array Value Type" ) 
	var someArray: [Int] = [10, 20, 30, 40, 50]

	// Object/Value Assignment i.e. Full Object/Value Get Copied	
	let someArrayCopy = someArray

	print(someArray)
	print(someArrayCopy)
	someArray[0] = 100
	print(someArray)
	print(someArrayCopy)

	// Tuples Are Value Type 
	print( "Experiment : Tuple Value Type" ) 
	var someTuple = ( 100, "Gabbar Singh")

	let someTupleCopy = someTuple
	print( someTuple )
	print( someTupleCopy )

	someTuple.0 = 420
	print( someTuple )
	print( someTupleCopy )
}

print("\nFunction: playWithValueTypes")
playWithValueTypes()

// Function: playWithValueTypes
// Resolution(width: 640, height: 480)
// Resolution(width: 640, height: 480)
// Resolution(width: 1920, height: 1080)
// Resolution(width: 640, height: 480)

//_____________________________________________________________
//_____________________________________________________________

class VideoMode {
	var resolution 		= Resolution()
	var frameRate 		= 0.0
	var name : String 	= "Uknonwn"
}

func playWithClassObject() {
	let hd = Resolution( width: 1920, height : 1080 )

	// Creating tenEighty Object Of Class VideoMode
	let tenEighty = VideoMode()
	print( tenEighty.resolution )
	print( tenEighty.frameRate )
	print( tenEighty.name )

	tenEighty.resolution = hd
	tenEighty.frameRate  = 60
	tenEighty.name 		 = "High Density"

	print( tenEighty.resolution )
	print( tenEighty.frameRate )
	print( tenEighty.name )	
}


print("\nFunction: playWithClassObject")
playWithClassObject()

//_____________________________________________________________
//_____________________________________________________________


func playWithClassReferenceType() {
	let hd = Resolution( width: 1920, height : 1080 )

	// Creating tenEighty Object Of Class VideoMode
	let tenEighty = VideoMode()
	tenEighty.resolution = hd
	tenEighty.frameRate  = 60
	tenEighty.name 		 = "High Density"

	// Reference Assignment i.e. Only Reference Get Copied
	let tenEightyCopy = tenEighty

	print("tenEighty Data: ")
	print( "\t", tenEighty.resolution )
	print( "\t", tenEighty.frameRate )
	print( "\t", tenEighty.name )	

	print("tenEightyCopy Data: ")
	print( "\t", tenEightyCopy.resolution )
	print( "\t", tenEightyCopy.frameRate )
	print( "\t", tenEightyCopy.name )	

	tenEighty.name = "Very High Density!!!"
	print("tenEighty Data: ")
	print( "\t", tenEighty.resolution )
	print( "\t", tenEighty.frameRate )
	print( "\t", tenEighty.name )	

	print("tenEightyCopy Data: ")
	print( "\t", tenEightyCopy.resolution )
	print( "\t", tenEightyCopy.frameRate )
	print( "\t", tenEightyCopy.name )		
}


print("\nFunction: playWithClassReferenceType")
playWithClassReferenceType()


//_____________________________________________________________
//_____________________________________________________________

func playWithClosuresReferenceType() {
	let increment 		= { () -> String in return "Hello" }
	let incrementCopy 	= increment

	print( increment() )
	print( incrementCopy() )
}

print("\nFunction: playWithClosuresReferenceType")
playWithClosuresReferenceType()


//_____________________________________________________________
//_____________________________________________________________

func makeIncrement(increment amount: Int ) -> () -> Int {
	var runningTotal = 0
	func incrementor() -> Int {
		runningTotal += amount
		return runningTotal
	}
	return incrementor
}

func playWithFunctionsReferenceTypes() {
	let something = makeIncrement(increment: 10)
	print(something())
	print(something())
	print(something())

	let somethingCopy = something
	print(somethingCopy())
	print(somethingCopy())
	print(somethingCopy())
}

print("\nFunction: playWithFunctionsReferenceTypes")
playWithFunctionsReferenceTypes()

//_____________________________________________________________
//_____________________________________________________________

func makeIncrementAgain(increment amount: Int ) -> () -> Int {
	var runningTotal = 0
	let incrementor = { () -> Int in 
		runningTotal += amount
		return runningTotal
	}
	return incrementor
}

func playWithClosuresReferenceTypes() {
	let something = makeIncrementAgain(increment: 10)
	print(something())
	print(something())
	print(something())

	let somethingCopy = something
	print(somethingCopy())
	print(somethingCopy())
	print(somethingCopy())
}

print("\nFunction: playWithClosuresReferenceTypes")
playWithClosuresReferenceTypes()

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")
