
//_____________________________________________________________
//
// Initialization
//_____________________________________________________________

struct Fahrenheit {
	var temperature: Double

	init() {
		temperature = 32.0
	}
}

func playWithInitialiser() {
	let fahrenheit = Fahrenheit()
	print("Default Temperature : \(fahrenheit.temperature)° Fahrenheit")
	print( fahrenheit )
}

print("\nFunction: playWithInitialiser")
playWithInitialiser()

//_____________________________________________________________
//_____________________________________________________________

// Customizing Initialization
// Initialization Parameters

struct Celsius {
	var temperatureInCelsius: Double = 0.0

	// Overloading Initiliser/Constructor Based On Parameter Name
	init(fromFahrenheit fahrenheit: Double) {
		temperatureInCelsius = (fahrenheit - 32) / 1.8
	}

	init(fromKelvin kelvin: Double) {
		temperatureInCelsius = kelvin - 273.15
	}
}

func playWithInitialiserOverloading() {
	let boilingPointOfWater 	= Celsius(fromFahrenheit: 212.0)
	let freezingPointOfWater 	= Celsius(fromKelvin: 273.15)
	print( boilingPointOfWater )
	print( freezingPointOfWater )
}

print("\nFunction: playWithInitialiserOverloading")
playWithInitialiserOverloading()

//_____________________________________________________________
//_____________________________________________________________

// Local/Internal and External Parameter Names

struct Color {
    let red, green, blue: Double

	// Overloading Initiliser/Constructor 
	//		Based On Parameter Name and Parameter Types and Numbers    
    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }

    init(white: Double) {
        red     = white
        green   = white
        blue    = white
    }
}

func playWithExternalAndInternalMethodParameters() {
	let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
	let halfGray = Color(white: 0.5)
	print( magenta )
	print( halfGray )
	// let verGreen = Color(0.0, 1.0, 0.0)
	// Compile time error because external names for parameters were omitted
}


print("\nFunction: playWithExternalAndInternalMethodParameters")
playWithExternalAndInternalMethodParameters()


//_____________________________________________________________
//_____________________________________________________________

// Initializer Parameters Without External Names
// Overloading Initiliser/Constructor 
//		Based On Parameter Name  

struct Celsius2 {
    var temperatureInCelsius: Double = 0.0

    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }

    init(_ celsius: Double) {
        temperatureInCelsius = celsius
    }
}

func playWithInitialiserInternalAndExternalParameters() {
	let bodyTemperature1 = Celsius2(37.0)
	print( bodyTemperature1 )

	let bodyTemperature2 = Celsius2(fromFahrenheit: 98.6 )
	print( bodyTemperature2 )

	let bodyTemperature3 = Celsius2(fromKelvin: 310.15)
	print( bodyTemperature3 )
}

print("\nFunction: playWithInitialiserInternalAndExternalParameters")
playWithInitialiserInternalAndExternalParameters()


//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

