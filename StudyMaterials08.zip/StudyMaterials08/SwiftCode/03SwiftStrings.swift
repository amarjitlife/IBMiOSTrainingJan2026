

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithStrings() {
	// Using Escape Sequences: Start with \ Backward Slash
	//		e.g. To Use " Symbol As Part String You Have To Escape It Using \ Backwards Slash
	//		Hence Use \" As Part Of String
	let someString = "\"Some String Value\""
	print(someString)

	// """ Paragraph """
	let bigString = """
	Vikram Batraa Zindabaad!!!
	Something More...
	Ye Dil Maangeee More....
	"""
	print(bigString)

	// Using Escape Sequences: Start with \ Backward Slash
	// \n Will Be Newline
	let bigStringAgain = "\nVikram Batraa Zindabaad!!!\nSomething More...\nYe Dil Maangeee More...."
	print(bigStringAgain)

	let softWrappedString = """

	Vikram Batraa Zindabaad!!! \
	Vikram Amar Rahain!... \
	Vikram Zindabaad!!!
	Something More...
	Ye Dil Maangeee More....
	"""
	print(softWrappedString)


	let bigStringMore = """

		Vikram Batraa Zindabaad!!!
				Something More...
		Ye Dil Maangeee More....

	"""
	print(bigStringMore)

	let bigStringOnceMore = """

		"Vikram Batraa Zindabaad!!!"
				Something More...
		Ye Dil Maangeee More....

	"""
	print(bigStringOnceMore)
}


print("\nFunction: playWithStrings")
playWithStrings()

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithStringsAgain() {
	let someString1 = "Some \"String\" Value"
	print(someString1)

	// Feature Added In Swift 5.0.1+
	let someString2 = #"Some "String" Value"#
	print(someString2)

	// # will ignore meaning of Escape Sequences
	let someString3 = #"Some \"String\" Value"#
	print(someString3)

	var oneString = "Rohit Sharma"
	// Calling String() Constructor To Create Empty String Object i.e. ""
	let oneMoreString = String() 

	if oneString.isEmpty {
		print("Emptiness Found")
	} else {
		print("String is Awesome!")
	}

	if oneMoreString.isEmpty {
		print("Emptiness Found")
	} else {
		print("String is Awesome!")
	}

	// Concating Strings
	oneString = oneString + oneMoreString
	var onceMoreString = "Hello Rockstar!"
	// Concating Strings
	onceMoreString = onceMoreString + oneString
	print(onceMoreString)

	for character in "Sachin" {
		print(character)
	}

	// Iterating Over String
	for character in oneString {
		print(character)
	}

	// oneString Contains "Rohit Sharma"
	// oneString[0] = "M"
	// `- error: cannot assign through subscript: subscript is get-only
	oneString = "Mohit Sharma"
	print(oneString)

	//let excalamationMark = "!"  			// excalamationMark is String Type
	let excalamationMark: Character = "!"	// Explicitly Mentioning Character Type

	print(excalamationMark)
	// oneString = oneString + excalamationMark
	// `- error: cannot convert value of type 'Character' to expected argument type 'String'

	oneString = oneString + String(excalamationMark)
	print(oneString)	
}

print("\nFunction: playWithStringsAgain")
playWithStringsAgain()

//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithCharactersArrayAndStrings() {
	// Array Of String Hence Type Is [String]
	let catCharacters1 = ["C", "a", "t", "🐱"]
	print( catCharacters1 )

	// Array Of Character Hence Type Is [Character]
	let charactersArray: [Character] = ["C", "a", "t", "🐱"]
	print( charactersArray )

	// Using String( ) Constructor To Construct String From Array of Character
	let catString = String( charactersArray )
	print(catString)

	// An arbitrary Unicode scalar value, written as \u{n}, 
	// where n is a 1–8 digit hexadecimal number (Unicode Point)
	let catCharacters2: [Character] = ["C", "a", "t", "\u{1F408}", "\u{1F431}" ]
	let catString2 = String(catCharacters2)
	print( catString2 )

	for character in catString2 {
		print( character )
	}
}

print("\nFunction: playWithCharactersArrayAndStrings")
playWithCharactersArrayAndStrings()


//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithUincodeCharacters() {

	let dollarSign = "\u{24}"
	print(dollarSign)

	let blackHeart = "\u{2665}"
	print(blackHeart)

	let sparklingHeart = "\u{1F496}"
	print(sparklingHeart)

	let catCharacters2: [Character] = ["C", "a", "t", "\u{1F408}", "\u{1F431}" ]
	let catString2 = String(catCharacters2)
	print( catString2 )

	// Get Each Indivisual Unicode Characters 
	for character in catString2 {
		print( character )
	}
}

print("\nFunction: playWithUincodeCharacters")
playWithUincodeCharacters()


//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithStringFunctions() {
	let string1 = "Hello " 
	let string2 = "World!"

	var welcome = string1 + string2
	print(welcome)

	welcome += " World is Awesome!"
	print(welcome)

	welcome.append(" and as well as horrible...")
	print(welcome)

	let badStart = """
	one
	two
	"""

	let end = """
	three
	"""

	print(badStart + end)

	let goodStart = """
	one
	two

	"""
	print(goodStart + end)

	let mutliplier = 3
	// String Interpolation - Values In \(Expr) get Substituted 
	// \(Expr) here Expr is evaluated and result is Substituted
	let message = "\(mutliplier) times 20 is \(mutliplier * 20)"
	print(message)

	//______________________________________________________________
	//
	// Supported SWIFT 5.0 Onwards
	//______________________________________________________________
	print(#""Life is Awesome", By SomeAnanda!"#)
	print(#""6 times 7 is \(6 * 7)""#)
	print(#""6 times 7 is \#(6 * 7)""#)
}

print("\nFunction: playWithStringFunctions")
playWithStringFunctions()


//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithUincodeCharactersAgain() {
	// Unicode Points
	print("\u{0061}")
	print("\u{1F618}")

	// A Unicode Character Can Be Represented With More Than One Unicode Points Combinations
	let eAcute: Character = "\u{E9}"
	print(eAcute)

	let eAcuteSplit1: Character = "\u{65}"
	let eAcuteSplit2: Character = "\u{301}"
	print(eAcuteSplit1)
	print(eAcuteSplit2)
	
	let eAcuteCombined: Character = "\u{65}\u{301}"
	print(eAcuteCombined)

	if eAcute == eAcuteCombined { // Phonetics
		print( "Both Are Equal!" )
	} else {
		print( "Both Are Not Equal!" )	
	}

	// Korean Language Uses Hangul Script
	// Hangul Syllables from the Korean alphabet can be represented 
	// as either a precomposed or decomposed sequence
	let precomposed: Character = "\u{D55C}"                  // 한
	let decomposed: Character = "\u{1112}\u{1161}\u{11AB}"   // ᄒ, ᅡ, ᆫ

	if precomposed == decomposed {
		print("Both Are Same")
	} else {
		print("Both Are Not Same")
	}

	let unusualMenagerie = "Koala 🐨, Snail 🐌, Penguin 🐧, Dromedary 🐪"
	print("unusualMenagerie has \(unusualMenagerie.count) characters")

	let koala = "Koala 🐨"
	print("koala has \(koala.count) characters")

	var word = "cafe"
	print(word, word.count)

	word += "\u{301}"
	print(word, word.count)
}

print("\nFunction: playWithUincodeCharactersAgain")
playWithUincodeCharactersAgain()


//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithStringIndexing() {	
	//Swift 5.0+ Onwards...
	let greeting = "Guten Tag!"

	let value1 = greeting[ greeting.startIndex ] 
	print(value1)

	let value3 = greeting[ greeting.index(after: greeting.startIndex) ]
	print(value3)

	let value2 = greeting[ greeting.index(before: greeting.endIndex) ]
	print(value2)


	let index = greeting.index(greeting.startIndex, offsetBy: 7)
	print( greeting[index] )

	// print( greeting[greeting.endIndex] )
	// print( greeting.index(after: greeting.endIndex) )

	for index in greeting.indices {
		print("At \(index) Value Is: \( greeting[index] )")
		// print("Value Is: \(greeting[index])")
	}

	print()
	for character in greeting {
		print("Value Is:", character)
	}

	// print(greeting.indices)

	var moreWelcome = "Hello"
	print(moreWelcome)

	// print( moreWelcome.index(after: moreWelcome.endIndex) )
	// print( moreWelcome.index(at: moreWelcome.endIndex) )

	moreWelcome.insert("?", at: moreWelcome.endIndex )
	print(moreWelcome)

	// let insertIndex = moreWelcome.endIndex
	// moreWelcome.insert(contentsOf: " World!", at: moreWelcome.index(before: insertIndex))
	moreWelcome.insert(contentsOf: " World!", at: moreWelcome.endIndex)
	print(moreWelcome)

	moreWelcome.remove(at: moreWelcome.index(before: moreWelcome.endIndex))
	print(moreWelcome)
}

print("\nFunction: playWithStringIndexing")
playWithStringIndexing()

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithStringEquality() {
	let quote = "We're a a lot alike, you and I."
	let sameQuote = "We're a a lot alike, you and I."

	if quote == sameQuote {
		print("Equal String...")
	} else {
		print("UnEqual String...")
	}

	let moreQuote = String("We're a a lot alike, you and I.")

	if quote == moreQuote {
		print("Equal String...")
	} else {
		print("UnEqual String...")
	}	
}

print("\nFunction: playWithStringEquality")
playWithStringEquality()


//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithStringEqualityAgain() {

	let eAcuteQuestion = "Voulez-vous un caf\u{E9}?" 					// E9 - é
	let combinedEAcuteQuestion1 = "Voulez-vous un caf\u{65}\u{301}?" 	// 65 - e, 301 ◌́
	let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"

	print(eAcuteQuestion)
	print(combinedEAcuteQuestion1)
	print(combinedEAcuteQuestion2)

// Voulez-vous un café?
// Voulez-vous un café?
// Voulez-vous un café?

	if eAcuteQuestion == combinedEAcuteQuestion1 {
		print("Equal String...")
	} else {
		print("UnEqual String...")
	}

	print(eAcuteQuestion)
	print(combinedEAcuteQuestion2)
	if eAcuteQuestion == combinedEAcuteQuestion2 {
		print("Equal String...")
	} else {
		print("UnEqual String...")
	}

	if combinedEAcuteQuestion1 == combinedEAcuteQuestion2 {
		print("Equal String...")
	} else {
		print("UnEqual String...")
	}

	//
	let latinCapitalLetterA: Character 		= "\u{41}"
	let cyrillicCapitalLetterA: Character 	= "\u{0410}"
	print(latinCapitalLetterA)
	print(cyrillicCapitalLetterA)

	if latinCapitalLetterA == cyrillicCapitalLetterA { // Phonetic Comparision
		print("Equal String...")
	} else {
		print("UnEqual String...")
	}
}

print("\nFunction: playWithStringEqualityAgain")
playWithStringEqualityAgain()


//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithStringFunctionsMore() {

	let movieDialogues: [String] = [
		"Act 1: Kitne Aaadmi Thee...",
		"Act 1: Mind block!",
		"Act 2: Once I Fix! That's It!",
		"Act 2: Ae Basanti En Kuto Ke Saamne Maat Nachnaaa...",
		"Act 1: All Is Well",
		"Act 2: Virus Verus Sastra Boodhi",
		"Act 1: Shorterm Memory Loss",
		"Act 1: Tareek pe Tareek"
	]

	var act1DialogueCount = 0
	var act2DialogueCount = 0

	print()
	for dialogue in movieDialogues {
		if dialogue.hasPrefix("Act 1:") {
			act1DialogueCount += 1
		} else if dialogue.hasPrefix("Act 2:") {
			act2DialogueCount += 1
		}

		if dialogue.hasSuffix("...") {
			print(dialogue)	
		}
	}

	print("Act 1 Dialogue Count: ", act1DialogueCount)
	print("Act 2 Dialogue Count: ", act2DialogueCount)
}


print("\nFunction: playWithStringFunctionsMore")
playWithStringFunctionsMore()

//_______________________________________________________________
//
//
//_______________________________________________________________

// Every Unicode String Made Of Unicode Characters
// Each Unicode Character Can Be Represented By Unicode Points In Multiple Ways
// Each Unicode String Can Have Encoding Format viz. UTF8, UTF16, UTF32

func playWithUnicodeEncoding() {

	let catCharacters1: [Character] = ["C", "a", "t", "\u{1F408}", "\u{1F431}" ]
	let catString1 = String(catCharacters1)
	print(catString1)  // Cat🐈🐱
	print( catString1, "Length: ", catString1.count ) // Cat🐈🐱 Length:  5

	for character in catString1 { // Unicode Character 
		print(character, terminator: " ## ")
	} // C ## a ## t ## 🐈 ## 🐱 ##

	print()

	// catString1.utf8 Gives Unicode Points In UTF8 Representation of Unicode String
	for codePoint in catString1.utf8 {
		print(codePoint, terminator: ", ")
	}
	// 67, 97, 116, 240, 159, 144, 136, 240, 159, 144, 177,


	let dogString = "Dog!!\u{1F436}"

	print("\n")
	print(dogString) // Dog!!🐶

	// Unicode Character “🐶” (U+1F436)
	// UTF-8 Encoding:	0xF0 0x9F 0x90 0xB6
	// UTF-16 Encoding:	0xD83D 0xDC36

	// UTF-32 Encoding:	0x0001F436

	// dogString.utf8 Gives Unicode Points In UTF8 Representation of Unicode String
	for c in dogString.utf8 {
		print(c, terminator: "   ")
	}
	// 68   111   103   33   33   240   159   144   182   

	print()

	// Unicode Character “🐶” (U+1F436)
	// UTF-16 Encoding:	0xD83D 0xDC36

	// dogString.utf16 Gives Unicode Points In UTF16 Representation of Unicode String
	for c in dogString.utf16 {
		print(c, terminator: "   ")
	}
	print()
	// 68   111   103   33   33   55357   56374 --- Base 10
	// 							  D83D	  DC36  --- Base 16

	// dogString.unicodeScalars Gives Unicode Points Compatiable To UTF32 Representation 
	//		of Unicode String	
	for c in dogString.unicodeScalars {
		print(c, terminator: "   ")
	}

	// When a Unicode string is written to a text file or some other storage, 
	//		the Unicode scalars in that string are encoded in one of several 
	//		Unicode-defined encoding forms. Each form encodes the string in 
	//		small chunks known as code units. These include the UTF-8 encoding 
	//		form (which encodes a string as 8-bit code units), 
	//		the UTF-16 encoding form (which encodes a string as 16-bit code units), 
	//		and the UTF-32 encoding form (which encodes a string as 32-bit code units).

	// Can Access a String value in one of three other Unicode-compliant representations:
	// A collection of UTF-8 code units (accessed with the string’s utf8 property)
	// A collection of UTF-16 code units (accessed with the string’s utf16 property)
	// A collection of 21-bit Unicode scalar values, equivalent to the string’s 
	//		UTF-32 encoding form (accessed with the string’s unicodeScalars property)
}

print("\nFunction: playWithUnicodeEncoding")
playWithUnicodeEncoding()


//_______________________________________________________________
//
//
//_______________________________________________________________



// print("\nFunction: ")

//_______________________________________________________________
//
//
//_______________________________________________________________


// print("\nFunction: ")


//_______________________________________________________________
//
//
//_______________________________________________________________


// print("\nFunction: ")

