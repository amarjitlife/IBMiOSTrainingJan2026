
//_____________________________________________________________
//_____________________________________________________________

func playWithInbuiltSubscriptOperator() {
	// Inbuilt Subscript Operator Usage With Dictionary
	var numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
	numberOfLegs["bird"] = 2
	print( numberOfLegs )

	var someArray : [Int] = [10, 20, 30, 40, 50 ]
	print( someArray )
	someArray[2] = 999
	print( someArray )
}

print("\nFunction: playWithInbuiltSubscriptOperator")
playWithInbuiltSubscriptOperator()

//_____________________________________________________________
//_____________________________________________________________

struct Table {
	let multiplier: Int

	// subscript Is Special Function
	//      Used To Overload Subscript Operator
	//      Taking One Argument Of Int Type and Returning Int Value
	subscript(index: Int) -> Int {
		print("Subscript Called...")
		return multiplier * index
	}
}

func playWithTable() {
	let threeTimesTable = Table(multiplier: 3)

	// Using Overloaded Subscript Operator
	// Compiler Will Generate Following Code For Below Line Of Code
	//      let something = threeTimesTable.subscript( index: 6 )
	let something = threeTimesTable[6] // threeTimesTable.subscript( index: 6 )
	print("six times three is \(something)")
}

print("\nFunction: playWithTable")
playWithTable()

//_____________________________________________________________
//_____________________________________________________________

struct Matrix {
	let rows: Int, columns: Int
	var grid: [Double]

	init( rows: Int, columns: Int) {
		self.rows = rows
		self.columns = columns
		grid = Array( repeating: 0.0, count : rows * columns )
	}

	func isValidIndex(row: Int, column: Int) -> Bool {
        return row >= 0 && row < rows && column >= 0 && column < columns
	}

	subscript( row: Int, column: Int ) -> Double {
		get {
			print("Subscript Getter Called...")
			assert( isValidIndex( row: row, column: column  ), "Index Out Of Range..." ) 
			return grid[ ( row * columns ) + column ]
		}

		set( setNewValue ) {
			print("Subscript Setter Called...")
			assert( isValidIndex( row: row, column: column ), "Index Out Of Range..." ) 
			grid[ ( row * columns ) + column ] = setNewValue
		}
	}
}

func playWithMatrix2D() {
	var matrix = Matrix( rows: 2, columns: 3 )
	print( matrix )

	print( matrix[0, 0 ] ) // matrix.subscript-get( row: 0, column: 0 )
	print( matrix[0, 1 ] ) // matrix.subscript-get( row: 0, column: 1 )

	matrix[0, 1] = 99.99   // matrix.subscript-set( row: 0, column: 1, 99.99 )
	print( matrix[0, 1 ] )

	matrix[1, 0] = 88.88
	print( matrix )

}

print("\nFunction:playWithMatrix2D ")
playWithMatrix2D()

//_____________________________________________________________
//_____________________________________________________________

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

// Type Subscript
// Instance subscripts, as described above, are subscripts that you call 
// on an instance of a particular type. 
// You can also define subscripts that are called on the type itself. 
// This kind of subscript is called a type subscript. 
// You indicate a type subscript by writing the static keyword 
// 		before the subscript keyword. 
// Classes can use the class keyword instead, to allow subclasses 
// to override the superclass’s implementation of that subscript.

enum Planet: Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune

    // substript Binded With Type
    static subscript( index: Int ) -> Planet {
        return Planet( rawValue: index )!
    }
}

func playWithEnumSubscriptOperator() {
	let mars = Planet[4]
	print( mars )
}

print("\nFunction: playWithEnumSubscriptOperator")
playWithEnumSubscriptOperator()


//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

