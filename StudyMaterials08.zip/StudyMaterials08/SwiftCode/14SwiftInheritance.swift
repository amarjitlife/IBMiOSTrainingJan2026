// Inheritance
//_____________________________________________________________
//_____________________________________________________________

// Vehicle Base Class
class Vehicle {
	var numberOfWheels: Int
	var maxPassengers: Int

	init() { // Constructor
		print("Vehicle init Called...")
		numberOfWheels = 0
		maxPassengers = 1
	}

	func description() -> String {
		return "Wheels: \(numberOfWheels) Maximum Passengers: \(maxPassengers) "
	}
}

// Vehicle Parent Class and Bicycle is Child Class
class Bicycle: Vehicle {
	override init() {
		print("Bicycle init Called...")
		super.init()
		numberOfWheels = 2
	}
}

// Bicycle Parent Class and Tandem is Child Class
class Tandem: Bicycle {
	override init() {
		print("Tandem init Called...")
		super.init()
		maxPassengers = 2
	}
}

func playWithInheritance() {
	let vehicle = Vehicle()
	print("Vehicle: \(vehicle.description())")

	let bicycle = Bicycle()
	print("Bicycle: \(bicycle.description())")

	let tandem = Tandem()
	print("Tandem: \(tandem.description())")
}

print("\nFunction: playWithInheritance")
playWithInheritance()

//_____________________________________________________________
//_____________________________________________________________

// Overriding
class Car: Vehicle {
	var speed: Double = 0.0

	// Overriding Constructor/Initialiser
	override init() {
		super.init()
		maxPassengers = 5
		numberOfWheels = 4
	}

	// Overriding Method/Member Function
	override func description() -> String {
		return super.description() + "; " + "traveling at \(speed) mph"
	}
}

func playWithOverridingInitilisorAndMemberFunction() {
	let car = Car()
	print("Car: \(car.description())")	
}

print("\nFunction: playWithOverridingInitilisorAndMemberFunction")
playWithOverridingInitilisorAndMemberFunction()


//_____________________________________________________________
//_____________________________________________________________


class SpeedLimitedCar: Car {
	// Overriding Member Property
	override var speed: Double {
		get { // Overriding Member Property Getter
			return super.speed
		}

		set { // Overriding Member Property Setter
			super.speed = min(newValue, 40.0)
		}
	}
}

func playWithOverridingProperty() {
	let limitedCar = SpeedLimitedCar()
	limitedCar.speed = 60.0
	print("SpeedLimitedCar: \(limitedCar.description())")
}

print("\nFunction: playWithOverridingProperty")
playWithOverridingProperty()

//_____________________________________________________________
//_____________________________________________________________

class AutomaticCar: Car {
	var gear = 1
	
	override var speed: Double {
		didSet { // 
			gear = Int(speed / 10.0) + 1
		}
	}
	
	override func description() -> String {
		return super.description() + " in gear \(gear)"
	}
}

func playWithOverridingPropertyAgain() {
	let automatic = AutomaticCar()
	automatic.speed = 35.0
	print("AutomaticCar: \(automatic.description())")
}

print("\nFunction: playWithOverridingPropertyAgain")
playWithOverridingPropertyAgain()

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")
