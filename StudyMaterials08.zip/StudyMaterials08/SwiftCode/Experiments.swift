

//_________________________________________________________


let number1: Double = 10.40
let divisior1: Int = 2
// let result1 = number1 / divisior1
// |- error: binary operator '/' cannot be applied to operands of type 'Double' and 'Int
let result1 = number1 / Double( divisior1 )
print(result1)

//_________________________________________________________

let number2: Double = 10.40
//	Compiler Optimisation Techniqe Is Used Here Constant Folding
//			Constat Expressions Get Evaluated At Compile Time
//			After Ealuation Resulting Value Type Is Inffered and Binded
let result2 = number2 / 2
print(result2)

//_________________________________________________________

let three = 3
let fractionPart = 0.1415
// let pi = three + fractionPart
// |- error: binary operator '+' cannot be applied to operands of type 'Int' and 'Double'
let pi = Double( three ) + fractionPart
print( pi )

// 3 + 0.1415 Expression 
//	1. Get Calcuated At Compile Time
//	2. Type Inferrencing On Value 3.1415 Is Done. Inffered Type Is Double
//  3. Type Binding To piAgain Variable Is Done. Type Of piAgain Will Be Double
let piAgain = 3 + 0.1415
print( piAgain )

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

