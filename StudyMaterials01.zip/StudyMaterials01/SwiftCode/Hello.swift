//_______________________________________________________________
//
// Windows Platform
//_______________________________________________________________

// 1. Create Following Directory Structures
// 		In Documents Directory
// 		1.1 Create iOSTraining Directory Inside Documents
// 		1.2 Create Progress Directory Inside Documents

// 2. Write Following Code In Hello.swift File
	
	print( "Hello World!" )

// 3. Save Program In Hello.swift In Progress Directory

// 4. Open Command Prompt Application
// 		cd YOUR_HOME_PATH\Documents\iOSTraining\Progress
//		dir

// 5. Compile Hello.swift
// 		swiftc Hello.swift

// 6. Run Compiled Code
// 		Hello

//_______________________________________________________________
//
//
//_______________________________________________________________

//_______________________________________________________________
//
//
//_______________________________________________________________

//_______________________________________________________________
//
//
//_______________________________________________________________

//_______________________________________________________________
//
//
//_______________________________________________________________

	