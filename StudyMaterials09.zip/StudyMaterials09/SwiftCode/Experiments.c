
#include <stdio.h>

void printArray( int numbers[], int len );

//_______________________________________________________________
//
// Constant, Variables, Initialisation and Types
//_______________________________________________________________
// Experiment Following Ideas In 
//		All Lanugages Swift, C/C++, Java, Python

void playWithInitialisationAndTypes() {
	// let maximumNumberOfLoginAttemps = 10
	const int maximumNumberOfLoginAttemps = 10;

	// var currentLoginAttempt = 0
	int currentLoginAttempt = 0;

	// var x = 0.0, y = 0.0, z = 0.0
	double x = 0.0, y = 0.0, z = 0.0;

	printf( "\n %d", maximumNumberOfLoginAttemps );
	printf( "\n %d", currentLoginAttempt );
	printf( "\n %f %f %f", x, y, z );

	// Definitions
	// let something1 : Int 
	// var something2 : Double

	// In C/C++ Local Variable Are Auto
	//		They Are Assigned Garbage Value
	int something1;
	double something2;

	printf( "\n %d", something1 );
	printf( "\n %f", something2 );

	something1 = 100;
	something2 =  88.88; // Initialise Before Usage
	printf( "\n %d", something1 );
	printf( "\n %f", something2 );
}

// BEST PRACTICE
//		Always Initialse Variable With Valid Values
//			Programmer Have To Do It!

//_______________________________________________________________

void playWithCString() {
	// In C/C++
	// ASCII String  "Gabbar Singh"
	char name[] = "Gabbar Singh";
	printf("\n Name: %s", name );

	// In C/C++
	//		Char Is ASCII Char
	//		For Every C Char There is An ASCII Code and Vice-Versa
	char ch = 'G'; // G ASCCI Code? = 71
	char ch1 = 71; 
	printf("\n Value: %c %c", ch, ch1 );
	printf("\n Value: %d %c", ch, ch1 );
}

//_______________________________________________________________

void playWithTypeRangeValues() {
	char some1 = 127;
	char some2 = 128;

	printf( "\n %d", some1 );
	printf( "\n %d", some2 );

	char some3 = -128;
	char some4 = -129;
	printf( "\n %d", some3 );
	printf( "\n %d", some4 );

	char some5 = 127;
	char some6 = some5 + 1;
	printf( "\n %d", some6 );

	char some55 = 128;
	char some66 = some55 + 1;
	printf( "\n %d", some66 );
}

// Function: playWithTypeRangeValues
//  127
//  -128
//  -128
//  127
//  -128
//  -127
 
//_______________________________________________________________


void playWithArrayCopying() {
	int someNumbers[6] = { 10, 20, 30, 40, 50, 60 };
	int someNumbersCopy[6];

	// someNumbersCopy = someNumbers;

	printArray( someNumbers, 6 );
	printArray( someNumbersCopy, 6 );

	someNumbersCopy[0] = 100;
	printArray( someNumbers, 6 );
	printArray( someNumbersCopy, 6 );	
}


//_______________________________________________________________

int sum( int a, int b ) {
	return a + b;
}

void playWithSum() {
	int a = 2147483647;
	int b = 11;

	int result = sum( a, b );
	printf("\nResult : %d", result );

	a = -2147483647;
	b = -11;
	result = sum( a, b );
	printf("\nResult : %d", result );
}

// Function: playWithSum
// Result : -2147483638
// Result : 2147483638

//_______________________________________________________________
//_______________________________________________________________

void printArray( int numbers[], int len ) {
	printf("\n");
	for ( int i = 0 ; i < len ; i++ ) {
		printf(" %d ", numbers[i] );
	}
}

void doChange( int a[], int size ) {
	for ( int i = 0 ; i  < size ; i++ ) {
		a[i] = 99;
	}
}

void doChangeMore( int * ptr, int size ) {
	for ( int i = 0 ; i  < size ; i++ ) {
		*( ptr + i ) = 33;
	}
}

void playWithArrays() {
	int a[5] = { 10, 20, 30, 40, 50 };
	printArray( a, 5 );

	doChange( a, 5 );
	printArray( a, 5 );

	doChangeMore( a, 5 );
	printArray( a, 5 );
}


//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________

int main() {
	printf("\n\nFunction: playWithInitialisationAndTypes");
	playWithInitialisationAndTypes();

	printf("\n\nFunction: playWithCString");
	playWithCString();

	printf("\n\nFunction: playWithTypeRangeValues");
	playWithTypeRangeValues();

	printf("\n\nFunction: playWithArrayCopying");
	playWithArrayCopying();

	printf("\n\nFunction: playWithSum");
	playWithSum();

	printf("\n\nFunction: playWithArrays");
	playWithArrays();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");	
}