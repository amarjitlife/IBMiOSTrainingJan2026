

//_____________________________________________________________
//_____________________________________________________________

// Function Type
//		() -> Unit
//		() -> ()
//		Unit Value In Swift Is () Empty Tuple
func hello() {
	print("Helloooo!")
}

// Function Type
//		() -> String
func sayHelloWorld() -> String {
	return "Hello World!"
}

// Function Type
//		( String ) -> String 
func sayHello( personName: String ) -> String {
	let greeting = "Hello " + personName + "!"
	return greeting
}

// Function Type
//		( Int, Int ) -> Int
func openRangeLength(start: Int, end: Int) -> Int {
	return end - start
}

// Function Type
//		( String ) -> Int
func printAndCount(stringToPrint: String ) -> Int {
	print(stringToPrint)
	return stringToPrint.count
}

func playWithFunctions() {
	print( "\nFunction : ", hello )
	
	// What Is The Type Of somethingN????
	let something1: () -> () = hello
	something1()

	let something2 : () -> String = sayHelloWorld
	_ = something2()

	let something3 : ( String ) -> String  	= sayHello
	let something4 : (Int, Int) -> Int 		= openRangeLength

	// What Is The Type Of somethingN????
	let something5 : String = something3( "Hello" )
	let something6 : Int = something4( 100, 200 )
	print( something5 )
	print( something6 )

	let something7 : (String) -> Int = printAndCount
	let something8 : Int = printAndCount(stringToPrint:  "Hello...." )
	print( something8 )

	let something9 	: (String) -> Int = something7
	print( something9 )
	let something10 : Int = something7( "Gabbar Singh" )
	print( something10 )

}

print("\nFunction: playWithFunctions")
playWithFunctions()


//_____________________________________________________________
//_____________________________________________________________

// Function Type
//		( [Int] ) -> (Int, Int )
func minimumMaximum( numbers : [Int] ) -> (min: Int, max: Int) {
	var currentMin = numbers[0]
	var currentMax = numbers[0]

	for number in numbers {
		if number > currentMax {
			currentMax = number
		} else if number < currentMin {
			currentMin = number
		}
	}
	return (currentMin, currentMax)
}

// let bounds = minimumMaximum( numbers : [10, 20, -90, 100, 800, -10, 3, 4, 5, 9])
// print(bounds)
// print("Minimum Value: \(bounds.0) \nMaximum Value: \(bounds.1)")
// print("Minimum Value: \(bounds.min) \nMaximum Value: \(bounds.max)")


//_____________________________________________________________
//_____________________________________________________________

// Hathi Ke Danth: Khaane Ke Aur and Deekhaanee Ke Aur
// Elephant's Teeths: To Show Off and To Eat

// External Parameters
// Internal Parameters

// Function Type
//		( String, String, String ) -> String 
func join(firstString s1: String, secondString s2: String, 
	joinWith joiner: String) -> String {
    return s1 + joiner + s2
}

//var resultString = join(s1: "hello", s2: "world", joiner: ", ") 
var resultString = join(firstString: "hello", secondString: "world", joinWith: ", ") 
print(resultString)


// Function Type
//		( String, String, String ) -> String 
// Other Non Standard Following Code or 3rd Party Library
func joinOther(s1: String, s2: String, joiner: String) -> String {
    return s1 + joiner + s2
}

resultString = joinOther( s1: "hello", s2: "world", joiner: ", ") 
print(resultString)


// Your Project Code
// Our Own APIs w.r.t. Project Guidelines
// 	Wrapper Function With Project Coding Conventions
// Function Type
//		( String, String, String ) -> String 

func joinStrings( firstString s1 : String, secondString s2: String, 
	joinWith joiner: String) -> String {
    return joinOther(s1: s1, s2: s2, joiner: joiner)
}

// Using New Function With Better Name Using In Our Own Project
resultString = joinStrings(firstString: "hello", secondString: "world", joinWith: ", ") 
print(resultString)


// //_____________________________________________________________
// //_____________________________________________________________

// Function Type
//		( String, Character ) -> Bool

// containCharacter Function Is An Object Of Function Type ( String, Character ) -> Bool
func containCharacter(string: String, searchCharacter: Character ) -> Bool {
	for character in string {
		if character == searchCharacter {  
			return true
		}
	}
	return false
}
let containResult = containCharacter(string: "Wonderful One!", searchCharacter: "O")

print(containResult)


//_____________________________________________________________
//_____________________________________________________________

// Polymorphic Function
// Using Mechanism: Function Overloading
//
//		Function Call Is Mapped To Specific Function Definition Based On
//			1. Types of Arguments
//			2. Number of Arguments
//			3. Labels of The Arguments

//		What Will Not Change : Function Name
//		What Else Can Change
//			1. Type Arguments
//			2. Number Of Arguments
//			3. Labels of The Arguments

// Function Type
//		(Int, Int) -> Int
func summation( x: Int, y: Int ) -> Int {
	print("Function Called: ", #function)
	return x + y 
}

// func summation( x: Int, y: Int ) -> Int {
// |      `- error: invalid redeclaration of 'summation(x:y:)'	
// 	print("Function Called: ", #function)
// 	return x * y 
// }

// Function Type
//		(Int, Int) -> Int
func summation( xx: Int, yy: Int ) -> Int { 
	print("Function Called: ", #function)
	return xx + yy 
}

func summation( x: Int, y: Int, z: Int ) -> Int { 
	print("Function Called: ", #function)
	return x + y + z
}

func summation( x: Float, y: Float ) -> Float { 
	print("Function Called: ", #function)
	return x + y 
}

func summation( x: String, y: String ) -> String { 
	print("Function Called: ", #function)
	return x + " " + y 
}


func playWithFunctionOverloading() {
	print( summation( x: 11, y: 22 ) )
	print( summation( xx: 10, yy: 20 ) )

	print( summation( x: 11, y: 22, z: 33 ) )
	print( summation( x: 99.99, y: 10.10 ) )
	print( summation( x: "Gabbar", y: "Singh") )
}

print("\nFunction: playWithFunctionOverloading")
playWithFunctionOverloading()


//_____________________________________________________________
//_____________________________________________________________

// Polymorphic Function
// Using Mechanism 
// 		1. Varidiac Argument Mechanism
//				Are Specified With ... Suffixed With Argument Type
//		2. Default Arguments
//				Are Assigned With Default Values 

//					Default Argument             Variable Number Of Arguments
func arithmeticMean(base: Double = 0.0, numbers: Double...) -> Double {
	var total = base
	for number in numbers {
		total = total + number
	}
	return total / Double(numbers.count)
}

var resultMean = arithmeticMean(base: 100, numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print(resultMean)
resultMean = arithmeticMean(numbers: 1, 2, 3, 4, 5, 6)
print(resultMean)
resultMean = arithmeticMean(numbers: 1, 2, 3, 4)
print(resultMean)
let someNumbers: [Double] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

//var resultMean = arithmeticMean(base: 100, numbers: someNumbers)

//_____________________________________________________________
//_____________________________________________________________

// Functions Have Type
// Following Functions sum And sub Function Type Is As Follows
// Function Type : (Int, Int) -> Int
func sum( x: Int, y: Int ) -> Int { return x + y }
func sub( x: Int, y: Int ) -> Int { return x - y }
func mul( x: Int, y: Int ) -> Int { return x * y }
func mod( x: Int, y: Int ) -> Int { return x % y }

// Function Type : (Int, Int, Int) -> Int
func sum3( x: Int, y: Int, z: Int ) -> Int { return x + y + z }

// Higher Order Functions
//		Functions Which Takes And/Or Returns Functions 


// Polymorphic Function
// Using Mechanism 
//		1. By Passing Function To A Function

// Following calcualtor Function Type Is As Follows
// Function Type : 
//		( Int, Int, (Int, Int) -> Int ) -> Int
func calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation( x, y )
}

func playWithCalculator() {
	let a: Int = 30
	let b: Int = 20

	// Passing a, b and sum Function To Function
	var result = calculator( x: a, y: b, operation: sum ) // Configuring With sum
	print("Result : ", result )

	// Passing a, b and sub Function To Function
	result = calculator( x: a, y: b, operation: sub ) 	// Configuring With sub
	print("Result : ", result )

	// Passing a, b and sub Function To Function
	result = calculator( x: a, y: b, operation: mul ) 	// Configuring With mul
	print("Result : ", result )

	result = calculator( x: a, y: b, operation: mod )  	// Configuring With mod
	print("Result : ", result )

	// result = calculator( x: a, y: b, operation: sum3 )
	// error: cannot convert value 
	//			of type '(Int, Int, Int) -> Int' 
	// 			to expected argument type '(Int, Int) -> Int'
	// print("Result : ", result )

	// What Is The Type Of something?
	//		It's A Function Type : (Int, Int) -> Int
	let something  = sum
	result = something( a, b )
	print("Result : ", result )

	let something1: (Int, Int) -> Int  = sum
	result = something1( a, b )
	print("Result : ", result )

	// What Is The Type Of somethingAgain?
	let somethingAgain = calculator
	result = somethingAgain( a, b, sum )
	print("Result : ", result )

	let somethingAgain1: (Int, Int, (Int, Int) -> Int ) -> Int = calculator
	result = somethingAgain1( a, b, sub )
	print("Result : ", result )

}

print("\nFunction: playWithCalculator")
playWithCalculator()


//_____________________________________________________________
//_____________________________________________________________

// Function Type
//		(Int) -> Int
func stepBackwards( input: Int ) -> Int { return input - 5 }
func stepForwards( input: Int ) -> Int  { return input + 5 }

// Function Type
//		(Bool) -> (Int) -> Int
func chooseSteps( forwards : Bool ) -> (Int) -> Int {
	return forwards ? stepForwards : stepBackwards
}

func playWithChooseSteps() {
	let something1: (Int) -> Int = stepForwards
	let something2: (Int) -> Int = stepBackwards
	print( something1 )
	print( something2 )

	let something3: (Bool) -> (Int) -> Int  = chooseSteps
	print( something3 )

	let something4: (Int) -> Int = chooseSteps( forwards: true )
	print( something4 )

	let something5: Int = something4( 100 )
	print( something5 )
}

print("\nFunction: playWithChooseSteps")
playWithChooseSteps()

//_____________________________________________________________
//_____________________________________________________________

// Function Type
//		(Bool) -> (Int) -> Int
func chooseStepsAgain( forwards : Bool ) -> (Int) -> Int {
	// Local Functions
	//		Functions Defined Inside A Function
	func stepBackwards( input: Int ) -> Int { return input - 5 }
	func stepForwards( input: Int ) -> Int  { return input + 5 }

	return forwards ? stepForwards : stepBackwards
}

func playWithChooseStepsAgain() {

	let something1: (Int) -> Int = chooseStepsAgain( forwards: false )
	print( something1 )

	let something2: Int = something1( 100 )
	print( something2 )

	let something4: (Int) -> Int = chooseStepsAgain( forwards: true )
	print( something4 )

	let something5: Int = something4( 100 )
	print( something5 )
}

print("\nFunction: playWithChooseStepsAgain")
playWithChooseStepsAgain()

//_____________________________________________________________
//_____________________________________________________________

// Function Arguments Are let Constants In Swift
func swap( a: Int, b: Int ) {
	var a = a
	var b = b

	let temp = a
	a = b
	 // `- error: cannot assign to value: 'a' is a 'let' constant
	b = temp
	 // `- error: cannot assign to value: 'b' is a 'let' constant
}

// Pass By Reference
func swapAgain( a: inout Int, b: inout Int ) {
	let temp = a
	a = b
	b = temp
}

func playWithSwapping() {
	var aa = 100
	var bb = 200
	// let aa = 100
	// let bb = 200

	print( aa, bb )
	swap( a: aa, b: bb )
	print( aa, bb )

	// Passing References Using &
	swapAgain( a: &aa, b: &bb )
	print( aa, bb )	
}

print("\nFunction: playWithSwapping")
playWithSwapping()

//_____________________________________________________________
//_____________________________________________________________


//Polymorphic Function
//		Using Mechanism Default Arguments

// Function Type
//		( String, String, String ) -> String
func createName(
	firstName: String, 
	middleName: String = "", 
	lastName: String = ""
) -> String {
	return firstName+middleName+lastName
}

func playWithCreateName() {
	print(createName(firstName: "Ram"))
	print(createName(firstName: "Ram", lastName: "Singh"))
	print(createName(firstName: "Ram", middleName: "Kapoor", lastName: "Singh"))
	print(createName(firstName: "Ram", middleName: "Kapoor"))
}

print("\nFunction: playWithCreateName")
playWithCreateName()

//_____________________________________________________________
//_____________________________________________________________


//_____________________________________________________________
//_____________________________________________________________


func makeIncrement(increment amount: Int ) -> () -> Int {
	var runningTotal = 0
	func incrementor() -> Int {
		runningTotal += amount
		return runningTotal
	}
	return incrementor
}

func playWithMakeIncrement() {
	var something = makeIncrement(increment: 10)
	print(something())
	print(something())
	print(something())

	something = makeIncrement(increment: 7)
	print(something())
	print(something())
	print(something())
}

print("\nFunction: playWithMakeIncrement")
playWithMakeIncrement()


//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

