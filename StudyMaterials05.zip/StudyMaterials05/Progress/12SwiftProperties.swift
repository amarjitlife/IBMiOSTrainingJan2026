
//_____________________________________________________________
//_____________________________________________________________

// Defining Structure/Type FixedLengthRange
struct FixedLengthRange {
	// Mutable Properties
	var firstValue: Int = 0
	var length : Int 	= 0
}

func playWitStructureObjectMutability() {
	// 
	var rangeOfThreeItems: FixedLengthRange = FixedLengthRange( firstValue: 0, length: 3 )
	print( rangeOfThreeItems )
	rangeOfThreeItems.firstValue = 66
	print( rangeOfThreeItems )

	// rangeOfThreeItems1 Becomes Immutable
	//		Hence It's Member Properties Also Treated Immutable
	let rangeOfThreeItems1: FixedLengthRange = FixedLengthRange( firstValue: 10, length: 3 )
	print( rangeOfThreeItems1 )
	// rangeOfThreeItems1.firstValue = 66
	// `- error: cannot assign to property: 'rangeOfThreeItems1' is a 'let' constant
	print( rangeOfThreeItems1 )
}

print("\nFunction: playWitStructureObjectMutability")
playWitStructureObjectMutability()


//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")

//_____________________________________________________________
//_____________________________________________________________

// print("\nFunction: ")
