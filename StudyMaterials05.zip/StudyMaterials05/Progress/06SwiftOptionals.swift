

//_______________________________________________________________
//
// BEST PRACTICE
//		Always Prefer Non Nullable Types Rather Than Nullable Types
//
//_______________________________________________________________

class Human {
	var name : String

	init( name : String ) {
		self.name = name
	}
}

// In Swift
//		By Default Objects/Types Are Non Nullable
//		You Cann't Assign nil Values To Objects
//		In Swift nil Is Corresponding To null In Java/C++

// In Java/C++/Python
//		By Default Objects/Types Are Nullable
//		You Can Assign null Values To Objects

func playWithNullabilityAndNonNullability() {
	//In Swift By Default All Types Are Non Nullable
	//	String, Int, Float, Double, Character, Human etc. All Are Non Nullable Types
	//		You Cann't Assign nil Values To Objects
	// var greeting: String 	= "Good Morning"
	// var number: Int 		= 999 
	// var ntr: Human 			= Human(name: "Nandamuri Taraka Ramarao")
	let greeting: String 	= "Good Morning"
	let number: Int 		= 999 
	let ntr: Human 			= Human(name: "Nandamuri Taraka Ramarao")

	print( greeting )
	print( number )
	print( ntr )

	// greeting 	= nil
	// number 		= nil
	// ntr 		= nil
	// `- error: 'nil' cannot be assigned to type 'String', 'Int', 'Human'
	print( greeting )
	print( number )
	print( ntr )

	//In Swift 
	// Type? Are Called Nullable/Optional Types 
	//	String?, Int?, Float?, Double?, Character?, Human? etc. All Are Nullable Types
	//		You Can Assign nil Values To Objects

	var greetingAgain: String? 	= "Good Morning"
	var numberAgain: Int? 		= 999 
	var ntrAgain: Human? 		= Human(name: "Nandamuri Taraka Ramarao")
	
	// print( greetingAgain )
	// print( numberAgain )
	// print( ntrAgain )
	print( greetingAgain ?? "Invalid Greeting Value" ) 
	print( numberAgain ?? "Invalid Number Value")
	print( ntrAgain ?? "Invalid ntrAgain Value")

	greetingAgain 	= nil
	numberAgain 	= nil
	ntrAgain 		= nil
	// `- error: 'nil' cannot be assigned to type 'String', 'Int', 'Human'

	// if greetingAgain Becomes nil Default Value Returned
						 // ?? Default Values	
	print( greetingAgain 	?? "Invalid Greeting Value") 
	print( numberAgain 		?? "Invalid Number Value")
	print( ntrAgain 		?? "Invalid ntrAgain Value")

}

print("\nFunction: playWithNullabilityAndNonNullability")
playWithNullabilityAndNonNullability()


//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithNullabilityHandling() {
	let someString : String = "Hello!"
	print("Value: ", someString)

	var someString1 : String? = "Hello!"
	print( someString1 )


	// DESIGN 01
	// First Check Optional Value != nil Before Unwrapping
	if someString1 != nil {
		// Getting Value From Optional Using Unwrapping !
		print( someString1! ) // Unwrapping Value From Optional
	} else {
		print("Invalid Value Found")
	}


	// DESIGN 02
	print( someString1 ?? "Invalid Value Found" )


	// Optional Unwrapping - But Got Disappointment
	// print("SomeString Value: ", someString1!) 

	// Always Check Optional Values for Non Nil
	// Then Only Unwrap

	if someString1 != nil {
		print("SomeString Unwrapped Value : ", someString1!) 
	} else {
		print("Found Nothing!")
	}

	someString1 = nil
	//print("SomeString Value: ", someString1)

	if someString1 != nil {
		print("SomeString Unwrapped Value : ", someString1!) 
	} else {
		print("Found Nothing!")
	}

	var someNumber: Int = 900
	print("Something Value: ", someNumber)
	// someNumber = nil

	var someNumber1: Int? = 900
	//print("Something Value: ", someNumber1)
	// someNumber1 = nil
	if someNumber1 != nil {
		print("Something Unwrapped Value: ", someNumber1!)
	} else {
		print("Found Nothing!")
	}

	var someDouble: Double = 900.90
	print("Something Value: ", someDouble)
	// someDouble = nil

	var someDouble1: Double? = 900.90
	//print("Something Value: ", someDouble1)
	// someDouble1 = nil

	if someDouble1 != nil {
		print("Something Unwrapped Value: ", someDouble1!)
	} else {
		print("Found Nothing!")	
	}

	someDouble1 = nil
	//print(someDouble1)
	//print("SomeString Value: ", someDouble1!) 
	if someDouble1 != nil {
		print("Something Unwrapped Value: ", someDouble1!)
	} else {
		print("Found Nothing!")	
	}

}

print("\nFunction: playWithNullabilityHandling")
playWithNullabilityHandling()

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithIfLetIdiom() {
	let possibleNumber : String = "12389"
	// let possibleNumber : String = "12389MUX"

	// Following Both Lines Are Same
	// let convertedNumber : Int? = Int( possibleNumber )
	let convertedNumber = Int( possibleNumber )
	print( convertedNumber ) // Optional(12389

	if convertedNumber != nil {
		print("Converted Number Value: ", convertedNumber! ) // Unwrapping Value From Optional
	} else {
		print("Found Nothing!")	
	}

	// Above Code Can Be Written Using if-let Idiom
	// Code 01: if let Idioms To Deal With Optionals
	// Here actualNumber Contains Unwrapped Values
	if let actutalNumber = Int( possibleNumber ) {
		print("Converted Number Value: ", actutalNumber )		
	} else {
		print("Found Nothing!")			
	}

	// Code 01: Compiler Will Generate Following Code For Above if-let Idiom
	let convertedOptional : Int? = Int( possibleNumber )
	if convertedOptional != nil {
		let actutalNumber : Int = convertedOptional!
		print("Converted Number Value: ", actutalNumber )		
	} else {
		print("Found Nothing!")			
	}

	// Code 02: if let Idioms To Deal With Multiple Optionals
	if let firstNumber = Int( "44"), let secondNumber = Int( "99" ), firstNumber < secondNumber {
		print(" \( firstNumber ) < \( secondNumber )" )
	} else {
		print("Something Else...")
	}

	// Code 02: Compiler Will Generate Following Code For Above if-let Idiom
	let firstNumberOptional 	= Int( "44" )
	let secondNumberOptional 	= Int( "99" )

	if firstNumberOptional != nil && secondNumberOptional != nil {
		let firstNumber 	= firstNumberOptional!
		let secondNumber 	= secondNumberOptional!

		if firstNumber < secondNumber {
			print(" \( firstNumber ) < \( secondNumber )" )
		} else {
			print("Something Else...")
		}
	}

	// Code 03: if let Idioms To Deal With Optionals
	// Here actualNumber Contains Unwrapped Values
	if var actutalNumber = Int( possibleNumber ) {
		actutalNumber = actutalNumber + 10
		print("Converted Number Value: ", actutalNumber )		
	} else {
		print("Found Nothing!")			
	}


	// Code 04: if let Idioms To Deal With Optionals
	let a: Int? = nil
	let b: Int? = 10
	let c: Int? = 8
	if let aa = a, let bb = b, let cc = c {
		print("Sum :", aa + bb + cc )
	} else {
		print("Life Is Messy!")
	}

	// Code 04: Compiler Will Generate Following Code For Above if-let Idiom

	if a != nil && b != nil && c != nil {
		let aa = a!
		let bb = b!
		let cc = c!
		print("Sum :", aa + bb + cc )
	} else {
		print("Life Is Messy!")
	}
}

print("\nFunction: playWithIfLetIdiom")
playWithIfLetIdiom()


//____________________________________________________________________
//
//Nil-Coalescing Operator OR Default Value Operator
//____________________________________________________________________


func playWithDefaultValueOperator() {
	// Common Code
	let defaultPrimeMinister = "Modi"
	let motherDefinedPrimeMinister : String? = "Manmohan Singh" // defaults to nil

	// Idiomatic Code: Programmer Written Code
	if let nationPrimeMinister = motherDefinedPrimeMinister {
	    print("\(nationPrimeMinister)")
	} else {
		let nationPrimeMinister = defaultPrimeMinister
	    print("\(nationPrimeMinister)")
	}

	// Elegant Idiomatic Code
	let nationPrimeMinister = motherDefinedPrimeMinister ?? defaultPrimeMinister
	print(nationPrimeMinister)

	// Compiler Generate Code
	let nationPrimeMinisterGenerated: String 
	if motherDefinedPrimeMinister != nil {
		nationPrimeMinisterGenerated = motherDefinedPrimeMinister!
	} else {
		nationPrimeMinisterGenerated = defaultPrimeMinister
	}
	print(nationPrimeMinisterGenerated)

	var xx: Int? = 100
	let defaultValue = 0
	let yy = xx ?? defaultValue
	print(yy)

	// For Following Code
		// let yy = xx ?? defaultValue
	// Equivalent Code
		// let yy = xx != nil ? xx! : defaultValue

	// The nil-coalescing operator (a ?? b) unwraps an optional a 
	//	if it contains a value, or returns a default value b if a is nil. 
	//	The expression a is always of an optional type. 
	//	The expression b must match the type that is stored inside a.

	// The nil-coalescing operator is shorthand for the code below:

	// a != nil ? a! : b	
}


print("\nFunction: playWithDefaultValueOperator")
playWithDefaultValueOperator()

