

// ______________________________________________________
//
// Creating An Empty Array
// ______________________________________________________

func playWithArrays() {
	// Creating Arrays Of Int With Zero Elements i.e. Empty Array
	// 				Constructor Call With Zero Arguments
 	var someInts = [Int]()
	print(someInts)

	if someInts.isEmpty {
		print("Emptiness Found...")
	} else {
		print("Not Empty Found...")	
	}

	// Creating Arrays Of Int With Zero Elements i.e. Empty Array
	var someInts1: [Int] = []
	print(someInts1)

	if someInts1.isEmpty {
		print("Emptiness Found...")
	} else {
		print("Not Empty Found...")	
	}

	someInts.append(10)
	someInts.append(20)
	someInts.append(30)
	print(someInts)

	someInts1 = [10, 20, 30]
	print(someInts1)

	someInts = [] // Emptying Tye Array
	print(someInts)

	let numbers: [Int] = [10, 20, 30, 40, 50] // Creating New Array Using Array Literal Syntax
	let numbersCopy 	= numbers 			  // Creating New Array Using Assignment
	let numbersAgain 	= [Int]( numbers )    // Creating New Array Using Constructor Call

	print( numbers ) 		// [10, 20, 30, 40, 50]
	print( numbersCopy ) 	// [10, 20, 30, 40, 50]
	print( numbersAgain ) 	// [10, 20, 30, 40, 50]

}

print("\nFunction: playWithArrays")
playWithArrays()


// ______________________________________________________
//
// Creating An Array With A Default Values
// ______________________________________________________

func playWithArraysAgain() {
	// Creating Array With 03 Elements And With Default Values 0.0
	//							 Calling Array Constructor
	var threeDoubles: [Double] = Array(repeating: 0.0, count: 3)
	print(threeDoubles)

	// Creating Array With 03 Elements And With Default Values 3.4
	var anotherThreeDoubles = Array(repeating: 3.4, count: 3)
	print(anotherThreeDoubles)

	// Concatenating Arrays
	var sixDoubles = threeDoubles + anotherThreeDoubles
	print(sixDoubles)

	//??? How to Add Multiple Elements in Array Using APIs

	// Createing Array Of String With Initialiation Values
	var shoppingList: [String] = ["Eggs", "Milks"]
	print(shoppingList)

	// Array [ Index ] Subscript Operator - Used To Access Members Of Array Using Index
	shoppingList[0] = "Bread"
	print(shoppingList)

	if shoppingList.isEmpty {
		print("Emptiness Found...")
	} else {
		print("Not Empty Found...")
	}

	shoppingList.append("Shoes")
	shoppingList.append("Socks")
	shoppingList.append("Eggs")
	print(shoppingList)

	shoppingList += ["Ding", "Dong"]
	print(shoppingList)

	let firstItem = shoppingList[0]
	print(firstItem)

	// 3...6 Range Operator It Means [3, 6] i.e. [3, 4, 5, 6]
	// It Replaces 04 Elements From Index 3, 4, 5 and 6 With Two Elements ["Bannas", "Apples"]
	shoppingList[4...6] = ["Bannas", "Apples"]
	print(shoppingList)

	shoppingList.insert("Mangoes", at: 0)
	print(shoppingList)

	var item = shoppingList.remove(at: 0)
	print(item)
	print(shoppingList)

	item = shoppingList.remove(at: 5)
	print(item)
	print(shoppingList)

	item = shoppingList.removeLast()
	print(item)
	print(shoppingList)

	for value in shoppingList {
		print(value)
	}

	for (index, value) in shoppingList.enumerated() {
		print("Item at \(index+1): \(value)")
	}
}

print("\nFunction: playWithArraysAgain")
playWithArraysAgain()

//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithArrayCopies() {
	// In Swift
	//		Arrays Are Value Types
	var someNumbers = [10, 20, 30, 40, 50, 60]
	var someNumbersCopy = someNumbers // Full Array Values Get Copied

	print(someNumbers)
	print(someNumbersCopy)

	someNumbersCopy[0] = 100

	print(someNumbers)
	print(someNumbersCopy)
}

print("\nFunction: playWithArrayCopies")
playWithArrayCopies()


//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithSets() {
	var letters = Set<Character>()
	letters.insert("9")
	letters.insert("A")
	letters.insert("B")
	letters.insert("0")
	letters.insert("A")

	print(letters)

	letters = []
	print(letters)

	var favoriteGenres: Set<String> = ["Classical", "Pop", "Sufi", "Pop" ]
	print(favoriteGenres)

	let favoriteGenres1: Set = ["Classical", "Pop", "Sufi", "Pop" ]
	print(favoriteGenres1)


	if favoriteGenres.isEmpty {
		print("Emptiness Found...")
	} else {
		print("Not Empty Found...")
	}

	favoriteGenres.insert("Jazz")
	favoriteGenres.insert("Classical")
	print(favoriteGenres)

	if let some = favoriteGenres.remove("Pop") {
		print(some)
	} else { 
		print("Nothingness Found...")
	}

	print(favoriteGenres)
	print("\nIterating Over A Set")
	for item in favoriteGenres {
		print(item)
	}
}

print("\nFunction: playWithSets")
playWithSets()

//_______________________________________________________________
//
//
//_______________________________________________________________

func playWithSetOperations() {
	var favoriteGenres: Set<String> = ["Classical", "Pop", "Sufi", "Pop" ]
	print(favoriteGenres)

	let favoriteGenres1: Set = ["Classical", "Pop", "Sufi", "Pop" ]
	print(favoriteGenres1)

	let oddDigits: Set = [1, 3, 5, 7, 9]
	let evenDigits: Set = [0, 2, 4, 6, 8]
	let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

	var result = oddDigits.union(evenDigits).sorted()
	print(result)
	// [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	result = oddDigits.intersection(evenDigits).sorted()
	print(result)
	// []
	result = oddDigits.subtracting(singleDigitPrimeNumbers).sorted()
	print(result)
	// [1, 9]
	result = oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted()
	print(result)
	// [1, 2, 9]

	let result1 = favoriteGenres.union(favoriteGenres1)
	print(result1)
}

print("\nFunction: playWithSetOperations")
playWithSetOperations()

//_______________________________________________________________
//
//
//_______________________________________________________________


func playWithDictionaries() {
	// Dictionary Is A Set Of (Key, Value) Tuples With Two Members First Key and Second Is Value
	// airports Is A Dictionary
	var airports: [String: String] = ["DEL": "Delhi", "BLR": "Bangalore", "MAA": "Chennai"]
	print(airports)

	// If Key Exists In The Dictionary 
	//		Than The Corresponding Value Is Returned For Given Key
	
	// If Key Doesn't Exists In The Dictionary 
	//		Than nil Value Is Returned For Given Key

	let bangalore = airports["BLR"]
	print( bangalore )

	if let air = airports["BLR"] {
		print(air)	
	} else {
		print("Nothingness Found...")	
	}

	// If Key Exists In The Dictionary 
	//		Assigining Value For Given Key Will Update Exisiting Value

	// If Key Doesn't Exists In The Dictionary 
	//		Assigining Value For Given Key Will Insert New Key, Value Pair

	airports["BLR"] = "Bangalore Airport"
	print(airports)

	airports["DBX"] = "Apna Dubai"
	print(airports)

	airports["DBX"] = "Dubai Airport"
	print(airports)

	print()
	for airport in airports {
		print( airport )
	}

	print()
	for (airportCode, airportName) in airports {
		print(airportCode, airportName, terminator: "   ")
	}

	print()
	for airportCode in airports.keys {
		print(airportCode, terminator: "   ")
	}

	print()
	for airportName in airports.values {
		print(airportName, terminator: "   ")
	}

	print()
	// Creating [String] Array Using Constructor Call
	//		Constructor Taking 1 Argument i.e. airports.keys
	let airportCodes = [String]( airports.keys )
	print(airportCodes)

	// Creating [String] Array Using Constructor Call
	//		Constructor Taking 1 Argument i.e. airports.keys
	let airportNames = [String]( airports.values )
	print(airportNames)
}

print("\nFunction: playWithDictionaries")
playWithDictionaries()


//_______________________________________________________________
//
//
//_______________________________________________________________

// print("\nFunction: ")

//_______________________________________________________________
//
//
//_______________________________________________________________

// print("\nFunction: ")

//_______________________________________________________________
//
//
//_______________________________________________________________

// print("\nFunction: ")

//_______________________________________________________________
//
//
//_______________________________________________________________

// print("\nFunction: ")

