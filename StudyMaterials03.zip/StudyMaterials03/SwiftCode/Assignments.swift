
_________________________________________________________________

DAY 01
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chapter 02: Types, Operators And Expressions

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.1 : Divide By Zero In Maximum Languages C/C++/Java/Python/JavaScript
				Mathematics
		A2.2 : Modulus Operator In Maximum Languages C/C++/Java/Python/JavaScript
				Mathematics
		A2.3 : Floating Point Comparision In Maximum Languages C/C++/Java/Python/JavaScript
				Mathematics

	Assignment A3 : Experiment Type Conversion Idea In Maximum Languages
			Swift/C/C++/Java/Python/TypeScript Languages

		print("\nExplicit Type Conversion")

		let label = "The Width is: "
		let width = 88
		// let labelledWidth = label + width
		// error: binary operator '+' cannot be applied to operands of type 'String' and 'Int

		// Explicit Type Conversion
		let labelledWidth = label + String( width )
		print( labelledWidth )

		let someFloatValue : Float = 10.10
		let someDoubleValue : Double = 99.99

		// let someValue1 = someFloatValue + someDoubleValue
		//  error: binary operator '+' cannot be applied to operands of type 'Float' and 'Double'

		let someValue1 = Double( someFloatValue ) + someDoubleValue 
		print( someValue1 )

		let someValue2 = someFloatValue + Float( someDoubleValue )
		print( someValue2 )

		let someIntValue1: Int8 	= 100
		let someIntValue2: Int16 	= 99

		// let someIntValue = someIntValue1 + someIntValue2 
		// error: binary operator '+' cannot be applied to operands of type 'Int8' and 'Int16

		let someIntValue11 = Int16( someIntValue1 ) + someIntValue2 
		print( someIntValue11 )

		let someIntValue12 = someIntValue1 + Int8( someIntValue2 )
		print( someIntValue12 )
	

	Assignment A4 : Swift Programming Language Reading and Experimentation Assignments

		SwiftTutorialsPart1.pdf
			1. Read All Chapters		
			2. Experiment All Code Examples
			3. Solve All Coding Challenges In Swift


_________________________________________________________________

DAY 02
_________________________________________________________________


	Assignment A1 : Swift Programming Language Reading and Experimentation Assignments
		SwiftTutorialsPart1.pdf
			1. Read All Chapters		
			2. Experiment All Code Examples In Swift
			3. Solve All Coding Challenges In Swift


	Assignment A2 : Reading, Thinking and Coding Assignments In Swift
		Swift Programming Guide
		Read Following Articles and Practice All Swift Code	
		L1. https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/
		L2. https://docs.swift.org/swift-book/documentation/the-swift-programming-language/basicoperators/


	Assignment A3 : Coding and Reasoning Assignments In Maximum Languages
		A2.1 : Divide By Zero In Maximum Languages C/C++/Java/Python/JavaScript
				Mathematics
		A2.2 : Modulus Operator In Maximum Languages C/C++/Java/Python/JavaScript
				Mathematics
		A2.3 : Floating Point Comparision In Maximum Languages C/C++/Java/Python/JavaScript
				Mathematics

_________________________________________________________________

DAY 03
_________________________________________________________________

	Assignment A1 : Swift Programming Language Reading and Experimentation Assignments
		SwiftTutorialsPart1.pdf
			1. Read All Chapters		
			2. Experiment All Code Examples In Swift
			3. Solve All Coding Challenges In Swift

		SwiftTutorialsPart2.pdf
			Chapter 7, Arrays, Dictionaries, and Sets
			Chapter 8, Collection Iterations With Closures
			Chapter 9, Strings

			1. Read All Chapters		
			2. Experiment All Code Examples In Swift
			3. Solve All Coding Challenges In Swift

	Assignment A2 : Reading, Thinking and Coding Assignments In Swift
		Swift Programming Guide
		Read Following Articles and Practice All Swift Code	
		L3. https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/
		L4. https://docs.swift.org/swift-book/documentation/the-swift-programming-language/collectiontypes/

_________________________________________________________________

DAY 0
_________________________________________________________________


_________________________________________________________________

DAY 0
_________________________________________________________________


