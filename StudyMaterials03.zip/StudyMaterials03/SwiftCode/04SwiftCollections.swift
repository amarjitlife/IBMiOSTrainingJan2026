

// ______________________________________________________
//
// Creating An Empty Array
// ______________________________________________________

var someInts = [Int]()
print(someInts)

if someInts.isEmpty {
	print("Emptiness Found...")
} else {
	print("Not Empty Found...")	
}

var someInts1: [Int] = []
print(someInts1)

if someInts1.isEmpty {
	print("Emptiness Found...")
} else {
	print("Not Empty Found...")	
}

someInts.append(10)
someInts.append(20)
someInts.append(30)
print(someInts)

someInts1 = [10, 20, 30]
print(someInts1)

someInts = []
print(someInts)

// ______________________________________________________
// Creating An Array With A Default Values
// ______________________________________________________

var threeDoubles: [Double] = Array(repeating: 0.0, count: 3)
print(threeDoubles)

var anotherThreeDoubles = Array(repeating: 3.4, count: 3)
print(anotherThreeDoubles)

var sixDoubles = threeDoubles + anotherThreeDoubles
print(sixDoubles)

//??? How to Add Multiple Elements in Array Using APIs

var shoppingList: [String] = ["Eggs", "Milks"]
print(shoppingList)
shoppingList[0] = "Bread"
print(shoppingList)

if shoppingList.isEmpty {
	print("Emptiness Found...")
} else {
	print("Not Empty Found...")
}

shoppingList.append("Shoes")
shoppingList.append("Socks")
shoppingList.append("Eggs")
print(shoppingList)

shoppingList += ["Ding", "Dong"]
print(shoppingList)

let firstItem = shoppingList[0]
print(firstItem)

shoppingList[4...6] = ["Bannas", "Apples"]
print(shoppingList)

shoppingList.insert("Mangoes", at: 0)
print(shoppingList)

var item = shoppingList.remove(at: 0)
print(item)
print(shoppingList)

item = shoppingList.remove(at: 5)
print(item)
print(shoppingList)

item = shoppingList.removeLast()
print(item)
print(shoppingList)

for value in shoppingList {
	print(value)
}

var someNumbers = [10, 20, 30, 40, 50, 60]
var someNumbersCopy = someNumbers
print(someNumbers)
print(someNumbersCopy)

someNumbersCopy[0] = 100
print(someNumbers)
print(someNumbersCopy)

for (index, value) in shoppingList.enumerated() {
	print("Item at \(index+1): \(value)")
}

var letters = Set<Character>()
letters.insert("9")
letters.insert("A")
letters.insert("B")
letters.insert("0")
letters.insert("A")

print(letters)

letters = []
print(letters)

var favoriteGenres: Set<String> = ["Classical", "Pop", "Sufi", "Pop" ]
print(favoriteGenres)

let favoriteGenres1: Set = ["Classical", "Pop", "Sufi", "Pop" ]
print(favoriteGenres1)


if favoriteGenres.isEmpty {
	print("Emptiness Found...")
} else {
	print("Not Empty Found...")
}

favoriteGenres.insert("Jazz")
favoriteGenres.insert("Classical")
print(favoriteGenres)

if let some = favoriteGenres.remove("Pop") {
	print(some)
} else { 
	print("Nothingness Found...")
}

print(favoriteGenres)
print("\nIterating Over A Set")
for item in favoriteGenres {
	print(item)
}


let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

var result = oddDigits.union(evenDigits).sorted()
print(result)
// [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
result = oddDigits.intersection(evenDigits).sorted()
print(result)
// []
result = oddDigits.subtracting(singleDigitPrimeNumbers).sorted()
print(result)
// [1, 9]
result = oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted()
print(result)
// [1, 2, 9]


let result1 = favoriteGenres.union(favoriteGenres1)
print(result1)


var airports: [String: String] = ["DEL": "Delhi", "BLR": "Bangalore", "MAA": "Chennai"]
print(airports)

if let air = airports["BLR"] {
	print(air)	
} else {
	print("Nothingness Found...")	
}

airports["BLR"] = "Bangalore Airport"
print(airports)

airports["DBX"] = "Apna Dubai"
print(airports)

airports["DBX"] = "Dubai Airport"
print(airports)

print()
for (airportCode, airportName) in airports {
	print(airportCode, airportName, terminator: "   ")
}

print()
for airportCode in airports.keys {
	print(airportCode, terminator: "   ")
}

print()
for airportName in airports.values {
	print(airportName, terminator: "   ")
}

print()
let airportCodes = [String](airports.keys)
print(airportCodes)

let airportNames = [String](airports.values)
print(airportNames)


//_______________________________________________________________
//
//
//_______________________________________________________________



// print("\nFunction: ")

//_______________________________________________________________
//
//
//_______________________________________________________________


// print("\nFunction: ")


//_______________________________________________________________
//
//
//_______________________________________________________________


// print("\nFunction: ")

